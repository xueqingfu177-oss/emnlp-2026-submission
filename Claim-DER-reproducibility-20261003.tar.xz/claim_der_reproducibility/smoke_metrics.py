"""Exercise worked examples and core diagnostic boundaries; no API calls."""
import ast
import hashlib
import importlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code/metrics'))
sys.path.insert(0,str(ROOT/'code/ablation'))
def canonical(x):
    if isinstance(x,ast.AST):return {'type':type(x).__name__,**{k:canonical(v) for k,v in ast.iter_fields(x) if k!='type_params'}}
    if isinstance(x,list):return [canonical(v) for v in x]
    return x
def main():
    trace=json.loads((ROOT/'examples/metric_trace.json').read_text(encoding='utf-8'))
    for key,evidence in trace['frozen_code'].items():
        tree=ast.parse((ROOT/'code/metrics'/(key+'.py')).read_text(encoding='utf-8'))
        nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
        digest=hashlib.sha256(json.dumps(canonical(nodes),sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()
        assert digest==evidence['function_ast_sha256'],key
    import run_ablation,surface,lexical
    run_ablation.prompt_audit()
    surface.tests()
    assert lexical.metrics(['a','b','c'],['a','b','c'])['RL_F1']==1.0
    assert not surface.check('A device with a sensor.')['pass']
    assert not run_ablation.legacy_skip('None of the listed features are captured.')
    assert run_ablation.legacy_skip(' none\n')
    for lang in ['en','zh']:
        dar=importlib.import_module('dar_'+lang)
        assert dar.get_node_health_status('')=={}
        par=importlib.import_module('par_'+lang)
        assert not any(par.map_features_to_positions(['absent_keyword'],'A device.'))
    en=importlib.import_module('dar_en')
    gold='1. A device comprising a pump.\n2. The device of claim 1, wherein the pump is metal.\n3. The device of claim 1, comprising a valve.\n4. The device of claim 3, wherein the valve is steel.'
    pred='1. A device comprising a pump.\n2. The device of claim 1, wherein the valve is metal.\n3. The device of claim 1, comprising a valve.'
    eligible=[i for i,ok in en.get_node_health_status(gold).items() if ok]
    generated=en.get_node_health_status(pred)
    assert len(eligible)==4 and sum(not generated.get(i,False) for i in eligible)==2
    print(json.dumps({'passed':True,'frozen_function_hash_groups':4,'worked_DAR_example':'2/4','api_calls':0}))
if __name__=='__main__':main()
