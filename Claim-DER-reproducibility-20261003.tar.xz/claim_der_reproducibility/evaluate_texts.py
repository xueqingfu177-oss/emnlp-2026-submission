"""Evaluate supplied generated texts with frozen PAR/DAR, ROUGE and surface rules."""
import argparse
import importlib
import importlib.metadata
import json
import re
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code/metrics'))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--language',required=True,choices=['en','zh'])
    p.add_argument('--predictions',required=True,type=Path,help='JSON list: publication_number, text; no duplicate IDs')
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--dar',action='store_true',help='Load the pinned spaCy models and compute DAR as well')
    a=p.parse_args()
    import jieba
    from rouge_score import rouge_scorer
    import lexical,surface
    par=importlib.import_module('par_'+a.language)
    if a.dar:
        for name,version in [('spacy','3.7.5'),('en-core-web-sm','3.7.1'),('zh-core-web-sm','3.7.0')]:
            assert importlib.metadata.version(name)==version,(name,'version differs from the archived DAR run')
        dar=importlib.import_module('dar_'+a.language)
    suffix={'en':'english','zh':'chinese'}[a.language]
    originals=json.loads((ROOT/f'dataset/data/{suffix}_1000.json').read_text(encoding='utf-8'))
    gold={r['publication_number']:r for r in originals}
    pred=json.loads(a.predictions.read_text(encoding='utf-8-sig'))
    assert isinstance(pred,list) and len({r['publication_number'] for r in pred})==len(pred)
    assert all(r['publication_number'] in gold and isinstance(r['text'],str) and r['text'].strip() for r in pred)
    tokenizer=rouge_scorer.RougeScorer(['rougeL'],use_stemmer=True)._tokenizer
    tokenize=tokenizer.tokenize if a.language=='en' else lambda s:[t.lower() for t in jieba.lcut(s) if t.strip()]
    rows=[]
    for r in pred:
        g=gold[r['publication_number']];text=r['text']
        keywords=getattr(par,'extract_'+suffix+'_keywords')(g['published_claim'],20)
        zones=par.map_features_to_positions(keywords,g['draft_description'])
        row={'publication_number':r['publication_number'],**lexical.metrics(tokenize(g['published_claim']),tokenize(text))}
        for name,features in zip(['head','mid','tail'],zones):
            hit=lambda k:bool(re.search(r'\b'+re.escape(k)+r'\b',text.lower())) if a.language=='en' else k.lower() in text.lower()
            row['PAR_'+name]=sum(hit(k) for k in features)/len(features) if features else None
            row['PAR_'+name+'_n_features']=len(features)
        result=surface.check(text)
        row.update(surface_pass=result['pass'],parseable=result['parseable'],claims=result['claims'],invalid_edges=result['invalid_edges'])
        if a.dar:
            eligible=[i for i,ok in dar.get_node_health_status(g['published_claim']).items() if ok]
            health=dar.get_node_health_status(text) if eligible else {}
            num=sum(not health.get(i,False) for i in eligible)
            row.update(DAR=num/len(eligible) if eligible else None,DAR_numerator=num,DAR_nodes=len(eligible))
        rows.append(row)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps({'language':a.language,'n':len(rows),'units':'fractions, not percentages',
        'cohort_note':'Scores for supplied predictions only; apply a shared ID intersection before multi-method comparison.',
        'DAR_aggregation':'sum numerators / sum nodes; do not average patent DAR fractions','rows':rows},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'evaluated':len(rows),'api_calls':0}))
if __name__=='__main__':main()
