"""Import recovered original output exports after checking their archived hashes."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--main',required=True,type=Path,help='Recovered baseline results/ directory')
    p.add_argument('--ablation',required=True,type=Path,help='Recovered corrected ablation results/ directory')
    p.add_argument('--output',required=True,type=Path,help='New destination; original archives are read only')
    a=p.parse_args()
    if a.output.exists():raise SystemExit('Use a new destination; never overwrite an existing archive.')
    hashes=read(ROOT/'protocols/expected_output_hashes.json')
    ids=read(ROOT/'dataset/manifests/selection.json')['selected_ids']
    ab_ids=read(ROOT/'protocols/ablation_selection.original.json')['selected_ids']
    pending=[];manifest={}
    for group,src in [('main',a.main),('ablation',a.ablation)]:
        for name,expected in hashes[group].items():
            path=src/name;digest=hashlib.sha256(path.read_bytes()).hexdigest()
            if digest!=expected:raise ValueError('Archived hash differs: '+group+'/'+name)
            records=read(path);lang=name.split('_',1)[0]
            assert len({r['publication_number'] for r in records})==len(records)
            allowed=set(ids[lang] if group=='main' else ab_ids[lang])
            assert all(r['publication_number'] in allowed and isinstance(r['text'],str) and r['text'].strip() for r in records)
            data=[{k:r[k] for k in ['publication_number','text']} for r in records]
            pending.append((group,name,data));manifest[group+'/'+name]={'original_sha256':digest,'records':len(records)}
    # All inputs are verified before any file is written.
    a.output.mkdir(parents=True)
    for group,name,data in pending:
        folder=a.output/group;folder.mkdir(exist_ok=True)
        path=folder/name;path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        manifest[group+'/'+name]['projection_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    (a.output/'IMPORT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'verified_exports':len(pending),'api_calls':0,
        'remaining':'Draft-only exports and raw request/checkpoint provenance are separate; this command does not synthesize or validate them.'}))
if __name__=='__main__':main()
