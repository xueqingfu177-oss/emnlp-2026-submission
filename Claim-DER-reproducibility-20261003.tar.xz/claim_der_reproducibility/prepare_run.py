"""Prepare a new, isolated baseline or ablation run. This command makes no API calls."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('kind',choices=['baselines','ablation'])
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args()
    out=a.output.resolve()
    if out.exists(): raise SystemExit('Output already exists. Use a new directory; existing runs are never overwritten.')
    out.mkdir(parents=True)
    for source in (ROOT/'code'/a.kind).glob('*.py'): shutil.copyfile(source,out/source.name)
    cfg=read(ROOT/'protocols'/(a.kind+'.json'))
    cfg.update(dataset=str(ROOT/'dataset'),output=str(out),run_id='portable_'+a.kind,
               archived_outputs=str(ROOT/'outputs/main'),archive_hashes=str(ROOT/'protocols/expected_output_hashes.json'))
    if a.kind=='ablation':
        selection=read(ROOT/'protocols/ablation_selection.original.json')
        selection['archive_source_hashes']=selection['source_hashes']
        selection['source_hashes']={k:v['sha256'] for k,v in read(ROOT/'dataset/manifests/data_files.json').items()}
        selection['release_note']='Same IDs and field strings; source-file hashes updated for the three-field projection.'
        save(out/'selection.json',selection)
        cfg['selection_sha256']=sha(out/'selection.json')
        save(out/'config.json',cfg)
        save(out/'PROTOCOL_FROZEN.json',{'release_adapter':True,'not_original_runtime_manifest':True,
            'files':{f.name:sha(f) for f in sorted(out.iterdir()) if f.is_file()}})
        command=f'python "{out / "run_ablation.py"}" --mode audit'
    else:
        save(out/'config.json',cfg)
        command=f'python "{out / "run_baselines.py"}" --config "{out / "config.json"}" --mode audit'
    print(command)
    print('Preparation only: no generation and no API charge. Explicit pilot/run modes call DashScope.')
if __name__=='__main__': main()
