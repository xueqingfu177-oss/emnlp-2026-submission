"""Verify recovered exports and reconstruct ablation request hashes offline."""
import csv,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code/ablation'))
import prompts
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha_bytes(x):return hashlib.sha256(x).hexdigest()
def sha_text(x):return sha_bytes(x.encode())
def clean(x):return re.sub(r'^```(?:text|plaintext)?\s*|\s*```$','',x.strip()).strip()
def main():
    manifest=read(ROOT/'outputs/IMPORT_MANIFEST.json')['files']
    expected=read(ROOT/'protocols/expected_output_hashes.json')
    outputs={}
    for name,entry in manifest.items():
        p=ROOT/'outputs'/name;digest=sha_bytes(p.read_bytes())
        assert digest==entry['sha256'],name
        group,file=name.split('/');lang,method=file.removesuffix('.json').split('_',1)
        if file in expected[group]:assert digest==expected[group][file]
        rows=read(p);index={r['publication_number']:r for r in rows}
        assert len(index)==len(rows)==entry['records']
        outputs[group,lang,method]=index
    data={lang:{r['publication_number']:r for r in read(ROOT/f'dataset/data/{name}_1000.json')}
          for lang,name in [('en','english'),('zh','chinese')]}
    with (ROOT/'provenance/ablation_stages.jsonl').open(encoding='utf-8') as f:stages=[json.loads(line) for line in f]
    index={s['path']:s for s in stages};assert len(index)==len(stages)
    for s in stages:
        parts=s['path'].split('/');lang,cid=parts[1:3];condition='/'.join(parts[3:-1])
        disclosure=data[lang][cid]['draft_description'];draft=outputs['ablation',lang,'draft_only'][cid]['text']
        if condition=='_shared/draft':messages=prompts.draft_prompt(disclosure,lang)
        elif condition in ['_shared/targeted','_shared/generic']:
            fn=prompts.targeted_prompt if condition.endswith('targeted') else prompts.generic_prompt
            messages=fn(disclosure,draft,lang)
        else:
            kind='generic' if condition=='generic_feedback' else 'targeted'
            feedback=index[f'cases/{lang}/{cid}/_shared/{kind}/feedback.json']['text']
            messages=prompts.revision_prompt(condition,disclosure,draft,feedback,lang)
        body={'model':s['requested_model'],'input':{'messages':messages},'parameters':s['parameters']}
        assert sha_text(json.dumps(body,ensure_ascii=False,sort_keys=True))==s['request_sha256'],s['path']
    bindings=0
    for (group,lang,method),rows in outputs.items():
        if group!='ablation':continue
        for cid,r in rows.items():
            paths=r['stage_paths'];draft=outputs['ablation',lang,'draft_only'][cid]['text']
            assert all(index[p]['status']=='ok' for p in paths)
            assert clean(index[paths[0]]['text'])==draft
            if method=='draft_only':assert len(paths)==1
            else:
                kind='generic' if method=='generic_feedback' else 'targeted'
                feedback=index[f'cases/{lang}/{cid}/_shared/{kind}/feedback.json']['text']
                skip=feedback.strip().upper()=='NONE'
                assert r['draft_sha256']==sha_text(draft) and r['feedback_sha256']==sha_text(feedback)
                assert r['legacy_none_skip']==skip and r['revision_executed']==(not skip)
                assert len(paths)==(2 if skip else 3)
                assert r['text']==(draft if skip else clean(index[paths[-1]]['text']))
            bindings+=1
    print(json.dumps({'passed':True,'export_files':len(manifest),'ablation_requests':len(stages),
                      'ablation_output_bindings':bindings,'api_calls':0}))
if __name__=='__main__':main()
