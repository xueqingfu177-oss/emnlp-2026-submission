"""Offline file-integrity, frozen-ID and text-hash checks."""
import csv
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=read(ROOT/'MANIFEST.json')
    for name,digest in manifest['files'].items():
        assert sha(ROOT/name)==digest,'Release file mismatch: '+name
    selected=read(ROOT/'dataset/manifests/selection.json')['selected_ids']
    fields=list(csv.DictReader((ROOT/'dataset/manifests/selected_samples.csv').open(encoding='utf-8-sig')))
    checks=0
    for lang,name in [('en','english'),('zh','chinese')]:
        rows=read(ROOT/f'dataset/data/{name}_1000.json')
        assert len(rows)==len({r['publication_number'] for r in rows})==1000
        assert sorted(r['publication_number'] for r in rows)==selected[lang]
        old={r['publication_number']:r for r in fields if r['language']==lang}
        for row in rows:
            for field in ['draft_description','published_claim']:
                assert hashlib.sha256(row[field].encode()).hexdigest()==old[row['publication_number']][field+'_sha256']
                checks+=1
    print(json.dumps({'passed':True,'release_files_verified':len(manifest['files']),
                      'original_text_field_hashes_verified':checks,'api_calls':0}))
if __name__=='__main__':main()
