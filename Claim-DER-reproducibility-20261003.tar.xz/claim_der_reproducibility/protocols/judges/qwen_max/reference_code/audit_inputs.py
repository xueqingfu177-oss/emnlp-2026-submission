"""Read-only input validation and deterministic blinded evaluation manifest."""
import hashlib
import json
from pathlib import Path
import random
import sys

ROOT=Path(__file__).resolve().parent
METHODS=['ft_llama3','qwen_turbo','qwen_max','self_refine','implicit_cot','plangen_bon5','claim_der']
DIMENSIONS=['Feature_Completeness','Conceptual_Clarity','Terminology_Consistency','Logical_Linkage','Overall_Quality']
LABELS=['Draft_'+x for x in 'ABCDEFG']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path,obj):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(path)


def mapping(config,case,variant):
    index=case['language_index']
    methods=METHODS.copy()
    rng=random.Random(f"{config['seed']}:{case['language']}:{index//7}:positions")
    rng.shuffle(methods)
    shift=(index%7+(3 if variant=='order_audit' else 0))%7
    methods=methods[shift:]+methods[:shift]
    return dict(zip(LABELS,methods))


def payload(config,case,variant):
    aliases=mapping(config,case,variant)
    data={'language':{'en':'English','zh':'Chinese'}[case['language']],
          'technical_disclosure':case['disclosure'],'published_reference_claims':case['reference'],
          'drafts':{label:case['drafts'][method] for label,method in aliases.items()}}
    messages=[{'role':'system','content':(ROOT/'rubric.txt').read_text(encoding='utf-8')},
              {'role':'user','content':json.dumps(data,ensure_ascii=False)}]
    seed=int(digest(f"{config['seed']}:{case['language']}:{case['publication_number']}:judge".encode())[:8],16)%2147483647
    parameters={'result_format':'message','temperature':config['temperature'],'seed':seed,
                'max_tokens':config['max_tokens'],
                'response_format':{'type':'json_object'}}
    return {'model':config['model'],'input':{'messages':messages},'parameters':parameters},aliases


def load():
    config=read(ROOT/'config.json')
    baseline=Path(config['baseline_run'])
    sys.path.insert(0,str(baseline))
    import run_baselines as previous
    previous_config=read(baseline/'config.json')
    previous.load_inputs(previous_config)
    expected=read(baseline/'bertscore_20260930/protocol.json')['input_hashes']
    actual={path:digest(Path(path).read_bytes()) for path in expected}
    assert actual==expected, 'Frozen inputs or evaluated outputs changed'
    audit={'input_sha256':actual,'config_sha256':digest((ROOT/'config.json').read_bytes()),
           'rubric_sha256':digest((ROOT/'rubric.txt').read_bytes()),'languages':{},'gpu_required':False,
           'model':config['model'],'limitations':['Stored disclosures were previously capped at30000 characters.',
           'Historical FT provenance and API snapshots remain unresolved. Qwen-family judge is not independent human evidence.']}
    cases=[]
    for lang,name in [('en','english'),('zh','chinese')]:
        records=read(Path(previous_config['dataset'])/'data'/f'{name}_1000.json')
        originals={x['publication_number']:x for x in records}
        assert len(originals)==1000
        outputs={}
        for method in METHODS:
            saved=read(baseline/'results'/f'{lang}_{method}.json')
            outputs[method]={x['publication_number']:x['text'] for x in saved}
            assert len(outputs[method])==len(saved)
        common=sorted(set.intersection(*(set(x) for x in outputs.values())))
        assert len(common)==config['primary_expected'][lang]
        selected=sorted(common,key=lambda cid:digest(f"{config['seed']}:{lang}:{cid}:order_audit".encode()))[:config['order_audit_per_language']]
        group=[]
        for index,cid in enumerate(common):
            original=originals[cid]
            case={'language':lang,'publication_number':cid,'language_index':index,
                  'disclosure':original['draft_description'],'reference':original['published_claim'],
                  'drafts':{m:outputs[m][cid] for m in METHODS},'order_audit':cid in selected}
            assert all(isinstance(x,str) and x.strip() for x in [case['disclosure'],case['reference'],*case['drafts'].values()])
            body,_=payload(config,case,'primary')
            # Bytes are a conservative size diagnostic, not a claimed exact cloud-token count.
            case['input_utf8_bytes']=len(json.dumps(body,ensure_ascii=False).encode())
            group.append(case)
        ordered=sorted(group,key=lambda x:(x['input_utf8_bytes'],x['publication_number']))
        # Select only by input size, never by scores or rankings. Prior-model counts
        # are pilot scheduling diagnostics, NOT exact Qwen-Max tokenization.
        pilot_pool=[]
        for case in group:
            prior=Path(config['prior_judge_run'])/'cases'/lang/case['publication_number']/'primary/result.json'
            if prior.exists():
                count=read(prior)['usage']['input_tokens']
                if count<=config['pilot_previous_input_max']:
                    pilot_pool.append((count,case['publication_number']))
        pilot_pool.sort()
        assert len(pilot_pool)>=3
        pilots=[pilot_pool[0][1],pilot_pool[len(pilot_pool)//2][1],pilot_pool[-1][1]]
        audit['languages'][lang]={'n':len(common),'missing_any_output':sorted(set(originals)-set(common)),
           'pilot_ids':pilots,'order_audit_ids':selected,'input_utf8_bytes':{'min':ordered[0]['input_utf8_bytes'],
           'median':ordered[len(ordered)//2]['input_utf8_bytes'],'max':ordered[-1]['input_utf8_bytes'],
           'sum':sum(x['input_utf8_bytes'] for x in group)}}
        cases.extend(group)
    return config,cases,audit,previous


if __name__=='__main__':
    config,cases,audit,_=load()
    save(ROOT/'input_audit.json',audit)
    print(json.dumps({'event':'judge_input_audit_complete','primary_cases':len(cases),
          'order_audit_cases':sum(x['order_audit'] for x in cases),'model':config['model'],
          'languages':audit['languages']},ensure_ascii=False))
