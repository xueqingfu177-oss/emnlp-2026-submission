"""Offline judge comparison on identical successful patents, never pooled scores."""
import csv
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parent
DIMENSIONS=['Feature_Completeness','Conceptual_Clarity','Terminology_Consistency','Logical_Linkage','Overall_Quality']
METHODS=['ft_llama3','qwen_turbo','qwen_max','self_refine','implicit_cot','plangen_bon5','claim_der']

def compare():
    cfg=json.loads((ROOT/'config.json').read_text(encoding='utf-8-sig'))
    runs={'qwen3_max':Path(cfg['prior_judge_run']),'qwen_max':ROOT}
    records={}
    for judge,path in runs.items():
        with (path/'per_case_scores.csv').open(encoding='utf-8-sig',newline='') as f:
            records[judge]={(r['language'],r['publication_number'],r['method']):r for r in csv.DictReader(f) if r['variant']=='primary'}
    rows=[]
    cohort={}
    lines=['# 两个裁判在共同成功样本上的比较','',
           '两个实验使用相同的五维评分标准、原始文本和匿名位置；Qwen-Max额外加强了引文来源字段指令，因此提示词并非字节一致；长输入超出Qwen-Max限制时保留缺失。以下两列均重新在完全相同的专利ID上统计，未混合两个裁判的分数。','']
    for lang in ['en','zh']:
        pools=[{cid for language,cid,method in records[j] if language==lang and method==m} for j in records for m in METHODS]
        ids=sorted(set.intersection(*pools))
        cohort[lang]=ids
        if not ids:continue
        lines.extend([f'## {lang}：共同{len(ids)}篇','','| 方法 | Qwen3-Max OQ | Qwen-Max OQ |','|---|---:|---:|'])
        for method in METHODS:
            means={judge:{d:statistics.mean(float(records[judge][lang,cid,method][d]) for cid in ids) for d in DIMENSIONS} for judge in records}
            for d in DIMENSIONS:
                rows.append({'language':lang,'method':method,'dimension':d,'n':len(ids),
                             'qwen3_max_mean':means['qwen3_max'][d],'qwen_max_mean':means['qwen_max'][d],
                             'qwen_max_minus_qwen3_max':means['qwen_max'][d]-means['qwen3_max'][d]})
            lines.append(f"| {method} | {means['qwen3_max']['Overall_Quality']:.3f} | {means['qwen_max']['Overall_Quality']:.3f} |")
        lines.append('')
    if rows:
        with (ROOT/'cross_judge_matched.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (ROOT/'cross_judge_cohort.json').write_text(json.dumps(cohort,indent=2),encoding='utf-8')
    lines.append('这是两个同族模型对同一输出的评价差异，不是生成质量改变的实验。需保留两轮完整结果及缺失记录；不能仅选有利裁判作为结论。')
    (ROOT/'CROSS_JUDGE.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'event':'cross_judge_comparison_complete','shared_counts':{k:len(v) for k,v in cohort.items()}}))

if __name__=='__main__':compare()
