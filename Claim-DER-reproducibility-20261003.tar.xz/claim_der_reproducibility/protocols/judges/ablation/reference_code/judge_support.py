"""Checkpointed seven-way blind judgment. All evaluation data stays separate from generation."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
from datetime import datetime, timezone
import gzip
import json
import math
import os
from pathlib import Path
import random
import re
import statistics
import sys
import threading
import time

import requests
from audit_inputs import ROOT,METHODS,DIMENSIONS,LABELS,read,save,digest,load,payload


def now():
    return datetime.now(timezone.utc).isoformat()


def csv_save(path,rows):
    if not rows:
        return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def normalize(text):
    return re.sub(r'\s+',' ',text).strip()


def parse(text, labels=None):
    labels=LABELS if labels is None else labels
    text=re.sub(r'^```(?:json)?\s*|\s*```$','',text.strip())
    obj=json.loads(text)
    if not isinstance(obj,dict) or set(obj)!=set(labels):
        raise ValueError('Expected exactly the supplied anonymous draft keys')
    for label in labels:
        value=obj[label]
        if not isinstance(value,dict) or set(value)!={'Scores','Reasoning','Support_Evidence'}:
            raise ValueError('Invalid draft fields')
        scores=value['Scores']
        if not isinstance(scores,dict) or set(scores)!=set(DIMENSIONS):
            raise ValueError('Invalid score dimensions')
        if not all(isinstance(x,int) and not isinstance(x,bool) and 1<=x<=10 for x in scores.values()):
            raise ValueError('Scores must be integers in1..10')
        if not isinstance(value['Reasoning'],str) or not value['Reasoning'].strip():
            raise ValueError('Missing assessment')
        evidence=value['Support_Evidence']
        if not isinstance(evidence,dict) or set(evidence)!={'candidate_quote','disclosure_quote'} or not all(isinstance(x,str) for x in evidence.values()):
            raise ValueError('Invalid support evidence schema')
    return obj


def evidence_audit(case,aliases,obj):
    result={}
    for label,method in aliases.items():
        evidence=obj[label]['Support_Evidence']
        a,b=normalize(evidence['candidate_quote']),normalize(evidence['disclosure_quote'])
        result[method]={'candidate_quote_present':bool(a),'disclosure_quote_present':bool(b),
                        'candidate_quote_found':bool(a) and a in normalize(case['drafts'][method]),
                        'disclosure_quote_found':bool(b) and b in normalize(case['disclosure'])}
    # This audit never rejects an otherwise valid numeric judgment or retries based on scores.
    return result


class FatalError(RuntimeError):
    pass


class Client:
    def __init__(self,config,key):
        self.config=config
        self.key=key
        self.stop=threading.Event()
        self.lock=threading.Lock()
        self.next_call=0.0

    def evaluate(self,case,variant):
        cfg=self.config
        if any(x['language']==case['language'] and x['publication_number']==case['publication_number']
               for x in cfg.get('known_provider_rejections',[])):
            raise RuntimeError('Not submitted: prior provider content-inspection rejection retained')
        directory=ROOT/'cases'/case['language']/case['publication_number']/variant
        directory.mkdir(parents=True,exist_ok=True)
        body,aliases=payload(cfg,case,variant)
        wire=json.dumps(body,ensure_ascii=False,sort_keys=True).encode()
        request_sha=digest(wire)
        result_path=directory/'result.json'
        if result_path.exists():
            record=read(result_path)
            assert record['request_sha256']==request_sha, 'Cached judgment request changed'
            return record
        with gzip.open(directory/'request.json.gz','wb') as f:
            f.write(wire)
        save(directory/'mapping.json',aliases)
        old=sorted(directory.glob('attempt_*.json'))
        for old_file in old:
            old_attempt=read(old_file)
            if old_attempt.get('status')=='api_error' and old_attempt.get('status_code')==400:
                raise RuntimeError('Prior nonretryable API 400 '+str(old_attempt.get('code','')))
        # A restart never exceeds the fixed per-request attempt budget.
        for attempt in range(len(old),cfg['max_attempts']):
            if self.stop.is_set():
                raise FatalError('Stopped after fatal transport/account response')
            with self.lock:
                delay=max(0,self.next_call-time.monotonic())
                self.next_call=max(self.next_call,time.monotonic())+1/cfg['requests_per_second']
            if self.stop.wait(delay):
                raise FatalError('Queue stopped')
            start=time.monotonic()
            record={'attempt':attempt+1,'time':now(),'request_sha256':request_sha,'requested_model':cfg['model']}
            target=directory/f'attempt_{attempt+1:02d}.json'
            try:
                response=requests.post(cfg['endpoint'],headers={'Authorization':'Bearer '+self.key},json=body,
                                       timeout=(20,cfg['timeout_seconds']))
                raw=response.json()
            except (requests.RequestException,ValueError) as exc:
                record.update(status='transport_uncertain',error_type=type(exc).__name__,seconds=time.monotonic()-start)
                save(target,record)
                if attempt+1<cfg['max_attempts']:
                    self.stop.wait(min(30,2**(attempt+1)))
                    continue
                raise RuntimeError('Transport attempt budget exhausted') from None
            code=str(raw.get('code',''))
            record.update(status_code=response.status_code,code=code,request_id=raw.get('request_id'),
                          usage=raw.get('usage',{}),seconds=time.monotonic()-start,
                          response_model=raw.get('model',raw.get('output',{}).get('model')))
            if response.status_code!=200:
                record['status']='api_error'
                record['api_message']=str(raw.get('message',''))[:1000]
                save(target,record)
                fatal=response.status_code in [401,402,403,404] or any(x in code.lower() for x in ['arrearage','invalidapikey','insufficient','modelnotfound'])
                if fatal:
                    self.stop.set()
                    raise FatalError(f'API {response.status_code} {code}')
                if response.status_code==429 or response.status_code>=500:
                    if attempt+1<cfg['max_attempts']:
                        self.stop.wait(min(30,2**(attempt+1)))
                        continue
                raise RuntimeError(f'API {response.status_code} {code}')
            try:
                choice=raw['output']['choices'][0]
                text=choice['message'].get('content','')
                finish=choice.get('finish_reason')
                record.update(text=text,finish_reason=finish)
                if not isinstance(text,str) or not text.strip() or finish!='stop':
                    raise ValueError('Output missing or not cleanly completed')
                obj=parse(text,list(aliases))
            except (KeyError,IndexError,TypeError,ValueError) as exc:
                record.update(status='invalid_response',error_type=type(exc).__name__,validation_error=str(exc)[:240])
                save(target,record)
                if attempt+1<cfg['max_attempts']:
                    continue
                raise RuntimeError('Schema/length attempt budget exhausted') from None
            record['status']='ok'
            save(target,record)
            final={'language':case['language'],'publication_number':case['publication_number'],'variant':variant,
                   'request_sha256':request_sha,'completed_at':now(),'mapping':aliases,'evaluation':obj,
                   'evidence_audit':evidence_audit(case,aliases,obj),'selected_attempt':attempt+1,
                   'model':cfg['model'],'response_model':record['response_model'],'usage':record['usage']}
            save(result_path,final)
            return final
        raise RuntimeError('Previously exhausted fixed attempt budget; inspect saved attempts')


def collect(config,cases,phase):
    records=[]
    usage=Counter()
    call_count=0
    estimated_cost=0.0
    uncertainty=0
    price=config['price_cny_per_million']
    for file in sorted((ROOT/'cases').glob('*/*/*/attempt_*.json')):
        attempt=read(file);call_count+=1
        u=attempt.get('usage',{})
        for key in ['input_tokens','output_tokens','total_tokens']:
            usage[key]+=u.get(key,0) or 0
        n=u.get('input_tokens',0) or 0
        tier='le_32k' if n<=32768 else ('le_128k' if n<=131072 else 'gt_128k')
        estimated_cost+=(n*price['input_'+tier]+(u.get('output_tokens',0) or 0)*price['output_'+tier])/1e6
        uncertainty+=attempt.get('status')=='transport_uncertain'
    for file in sorted((ROOT/'cases').glob('*/*/*/result.json')):
        result=read(file)
        for label,method in result['mapping'].items():
            judgment=result['evaluation'][label]
            records.append({'language':result['language'],'publication_number':result['publication_number'],
                            'variant':result['variant'],'method':method,'position':label,
                            **judgment['Scores'],**result['evidence_audit'][method]})
    csv_save(ROOT/'per_case_scores.csv',records)
    counts={lang:{variant:len({r['publication_number'] for r in records if r['language']==lang and r['variant']==variant}) for variant in ['primary','order_audit']} for lang in ['en','zh']}
    status={'phase':phase,'updated_at':now(),'pid':os.getpid(),'completed':counts,
            'primary_target':config['primary_expected'],'order_audit_target_per_language':config['order_audit_per_language'],
            'api_attempts':call_count,'reported_usage':dict(usage),'estimated_list_price_cny':estimated_cost,
            'transport_uncertain_attempts':uncertainty,'note':'Estimate excludes unreported usage and account-specific discounts; no winning-score selection.'}
    save(ROOT/'status.json',status)
    summaries=[]
    for lang in ['en','zh']:
        for method in METHODS:
            group=[r for r in records if r['language']==lang and r['variant']=='primary' and r['method']==method]
            if not group:continue
            summaries.append({'language':lang,'method':method,'n':len(group),
                              **{d:statistics.mean(x[d] for x in group) for d in DIMENSIONS},
                              'both_quotes_traceable_pct':100*statistics.mean(x['candidate_quote_found'] and x['disclosure_quote_found'] for x in group)})
    csv_save(ROOT/'summary_scores.csv',summaries)
    save(ROOT/'summary.json',{'status':status,'primary':summaries})
    return records,status


def run_phase(client,config,tasks,phase):
    random.Random(f"{config['seed']}:{phase}:dispatch").shuffle(tasks)
    errors=[]
    started=time.monotonic()
    last_status=0.0
    with ThreadPoolExecutor(max_workers=config['workers']) as pool:
        pending={pool.submit(client.evaluate,case,variant):(case,variant) for case,variant in tasks}
        for count,future in enumerate(as_completed(pending),1):
            case,variant=pending[future]
            try:
                future.result()
            except Exception as exc:
                error={'language':case['language'],'publication_number':case['publication_number'],
                       'variant':variant,'type':type(exc).__name__,'message':str(exc)[:240]}
                errors.append(error)
                save(ROOT/'cases'/case['language']/case['publication_number']/variant/'error.json',error)
                if isinstance(exc,(FatalError,AssertionError)):
                    client.stop.set()
                    for job in pending:job.cancel()
                    break
            if time.monotonic()-last_status>=45 or count==len(tasks):
                _,state=collect(config,[],phase+'_running')
                print(json.dumps({'event':'judge_progress','phase':phase,'tasks_done':count,'tasks_total':len(tasks),
                                  'errors':len(errors),'completed':state['completed'],'seconds':time.monotonic()-started}),flush=True)
                last_status=time.monotonic()
    save(ROOT/(phase+'_errors.json'),errors)
    return errors


def final_report(config,cases,audit):
    import numpy as np
    records,status=collect(config,cases,'complete' if all((ROOT/'cases'/c['language']/c['publication_number']/v/'result.json').exists()
        for c in cases for v in (['primary','order_audit'] if c['order_audit'] else ['primary'])) else 'finished_with_failures')
    summary=read(ROOT/'summary.json')['primary']
    by={(x['language'],x['publication_number'],x['variant'],x['method']):x for x in records}
    pairs=[]
    order=[]
    for lang in ['en','zh']:
        ids=sorted({x['publication_number'] for x in records if x['language']==lang and x['variant']=='primary'})
        for metric in DIMENSIONS:
            for other in [m for m in METHODS if m not in ['claim_der','ft_llama3']]:
                differences=np.array([by[(lang,cid,'primary','claim_der')][metric]-by[(lang,cid,'primary',other)][metric] for cid in ids])
                if not len(differences):continue
                rng=np.random.default_rng(int(digest(f"{config['seed']}:{lang}:{metric}:{other}:bootstrap".encode())[:8],16))
                values=np.concatenate([differences[rng.integers(0,len(differences),size=(500,len(differences)))].mean(axis=1) for _ in range(40)])
                lo,hi=np.quantile(values,[.025,.975])
                base=statistics.mean(by[(lang,cid,'primary',other)][metric] for cid in ids)
                pairs.append({'language':lang,'dimension':metric,'baseline':other,'n':len(ids),
                              'delta_points':float(differences.mean()),'relative_gain_pct':100*float(differences.mean())/base,
                              'ci95_low':float(lo),'ci95_high':float(hi)})
        for method in METHODS:
            repeated=[cid for cid in ids if (lang,cid,'order_audit',method) in by]
            if not repeated:continue
            for metric in DIMENSIONS:
                delta=[by[(lang,cid,'order_audit',method)][metric]-by[(lang,cid,'primary',method)][metric] for cid in repeated]
                order.append({'language':lang,'method':method,'dimension':metric,'n':len(delta),
                              'mean_change':statistics.mean(delta),'mean_absolute_change':statistics.mean(abs(x) for x in delta),
                              'exact_score_agreement_pct':100*statistics.mean(x==0 for x in delta)})
    csv_save(ROOT/'paired_bootstrap.csv',pairs)
    csv_save(ROOT/'order_sensitivity.csv',order)
    missing=[{'language':c['language'],'publication_number':c['publication_number'],'variant':v}
             for c in cases for v in (['primary','order_audit'] if c['order_audit'] else ['primary'])
             if not (ROOT/'cases'/c['language']/c['publication_number']/v/'result.json').exists()]
    save(ROOT/'missing_judgments.json',missing)
    lines=['# 新版五维LLM评价','',f"裁判：{config['model']}。状态：{status['phase']}。主评价不混用历史分数，也不按分数选择重试。",'']
    for lang in ['en','zh']:
        lines.extend([f'## {lang}','','| 方法 | n | FC | CC | TC | LL | OQ | 引文可定位比例 |','|---|---:|---:|---:|---:|---:|---:|---:|'])
        for row in summary:
            if row['language']!=lang:continue
            lines.append('| '+row['method']+' | '+str(row['n'])+' | '+' | '.join(f'{row[d]:.3f}' for d in DIMENSIONS)+f" | {row['both_quotes_traceable_pct']:.1f}% |")
    lines.extend(['','引文可定位只检查字符串是否存在，不等于证明语义支持；未定位引文不触发重评分。',
                  '顺序复测仅用于稳定性诊断，详见order_sensitivity.csv；完整提示词与配置已冻结保存。',
                  '置信区间为20000次专利级配对bootstrap的逐项95%区间，未做多重比较或专利族聚类调整。',
                  'Qwen-Max上下文超限及已知内容检查拒绝保留为缺失；跨裁判比较必须重算共同成功样本。',
                  'Qwen同族裁判偏差、历史API版本、FT训练重合风险和披露既有30000字符上限仍存在。本结果不是人工评测或法律有效性认证。'])
    (ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'event':'judge_finished',**status}),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['audit','pilot','run','status'],required=True)
    args=parser.parse_args()
    if args.mode=='status':
        print(json.dumps(read(ROOT/'status.json'),ensure_ascii=False));return
    config,cases,audit,previous=load()
    save(ROOT/'input_audit.json',audit)
    if args.mode=='audit':
        print(json.dumps({'event':'judge_input_audit_complete','primary_cases':len(cases),'model':config['model']}));return
    lock=ROOT/'run.lock'
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        fingerprint={'config':digest((ROOT/'config.json').read_bytes()),'rubric':audit['rubric_sha256'],
                     'input_sha256':audit['input_sha256'],'scoring_code':digest(Path(__file__).read_bytes()),
                     'payload_code':digest((ROOT/'audit_inputs.py').read_bytes())}
        if (ROOT/'frozen_protocol.json').exists():
            assert read(ROOT/'frozen_protocol.json')==fingerprint,'Protocol or inputs changed; use a new run ID'
        else:save(ROOT/'frozen_protocol.json',fingerprint)
        key=previous.credential(read(Path(config['baseline_run'])/'config.json')['credential_source'])
        client=Client(config,key)
        selected=[c for c in cases if c['publication_number'] in audit['languages'][c['language']]['pilot_ids']]
        errors=run_phase(client,config,[(c,'primary') for c in selected],'pilot')
        pilot_rows,_=collect(config,cases,'pilot_complete' if not errors else 'pilot_failed')
        trace=[x['candidate_quote_found'] and x['disclosure_quote_found'] for x in pilot_rows if x['publication_number'] in audit['languages'][x['language']]['pilot_ids'] and x['variant']=='primary']
        pilot={'n_patents':len(selected),'expected_candidates':42,'completed_candidates':len(trace),'errors':errors,
               'quote_traceable_count':sum(trace),'quote_traceable_rate':statistics.mean(trace) if trace else 0,
               'technical_pass':not errors and len(trace)==42,
               'evidence_traceability_pass':len(trace)==42 and statistics.mean(trace)>=0.8,
               'gate_note':'Predeclared literal evidence-traceability threshold; not a semantic accuracy certification or method-rank gate.'}
        save(ROOT/'pilot_summary.json',pilot)
        if not pilot['technical_pass'] or not pilot['evidence_traceability_pass']:
            collect(config,cases,'pilot_requires_review')
            print(json.dumps({'event':'pilot_requires_review','pilot':pilot}),flush=True);return
        if args.mode=='pilot':return
        primary=[(c,'primary') for c in cases]
        run_phase(client,config,primary,'primary')
        if not client.stop.is_set():
            run_phase(client,config,[(c,'order_audit') for c in cases if c['order_audit']],'order_audit')
        final_report(config,cases,audit)
        from compare_judges import compare
        compare()
    finally:
        lock.unlink(missing_ok=True)


if __name__=='__main__':
    main()
