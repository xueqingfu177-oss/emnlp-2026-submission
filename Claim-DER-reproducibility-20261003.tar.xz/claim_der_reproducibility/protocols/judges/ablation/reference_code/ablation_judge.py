"""Qwen-Max five-dimensional evaluation of corrected ablations, with exact-text ties."""
import argparse,csv,json,statistics,sys,time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import audit_inputs as a
import judge_support as j
ROOT=a.ROOT
def emit(**x):print(json.dumps(x,ensure_ascii=False),flush=True)
def collect(cases,phase):
    rows=[];unique_rows=[];usage=Counter();attempts=0;uncertain=0
    for p in (ROOT/'cases').glob('*/*/*/attempt_*.json'):
        r=a.read(p);attempts+=1;uncertain+=r.get('status')=='transport_uncertain'
        for k in ['input_tokens','output_tokens','total_tokens']:usage[k]+=r.get('usage',{}).get(k,0) or 0
    for case in cases:
        for variant in ['primary','order_audit']:
            p=ROOT/'cases'/case['language']/case['publication_number']/variant/'result.json'
            if not p.exists():continue
            result=a.read(p);body,aliases=a.payload(a.read(ROOT/'config.json'),case,variant)
            assert result['request_sha256']==a.digest(json.dumps(body,ensure_ascii=False,sort_keys=True).encode())
            scores={key:result['evaluation'][label] for label,key in result['mapping'].items()}
            for label,key in result['mapping'].items():
                unique_rows.append({'language':case['language'],'publication_number':case['publication_number'],'variant':variant,'text_sha256':key,'position':label,**scores[key]['Scores'],**result['evidence_audit'][key]})
            for method,key in case['method_groups'].items():
                rows.append({'language':case['language'],'publication_number':case['publication_number'],'variant':variant,'method':method,'text_sha256':key,'identical_text_methods':','.join(m for m,g in case['method_groups'].items() if g==key),**scores[key]['Scores'],**result['evidence_audit'][key]})
    j.csv_save(ROOT/'per_case_scores.csv',rows);j.csv_save(ROOT/'per_unique_text_scores.csv',unique_rows)
    state={'phase':phase,'updated_at':j.now(),'primary_target':{l:sum(c['language']==l for c in cases) for l in ['en','zh']},'completed':{l:{v:len({r['publication_number'] for r in rows if r['language']==l and r['variant']==v}) for v in ['primary','order_audit']} for l in ['en','zh']},'api_attempts':attempts,'reported_usage':dict(usage),'transport_uncertain_attempts':uncertain}
    a.save(ROOT/'status.json',state)
    summaries=[]
    for lang in ['en','zh']:
        for m in a.METHODS:
            group=[r for r in rows if r['language']==lang and r['method']==m and r['variant']=='primary']
            if group:summaries.append({'language':lang,'method':m,'n':len(group),**{d:statistics.mean(r[d] for r in group) for d in a.DIMENSIONS},'both_quotes_traceable_pct':100*statistics.mean(r['candidate_quote_found'] and r['disclosure_quote_found'] for r in group)})
    j.csv_save(ROOT/'summary_scores.csv',summaries);a.save(ROOT/'summary.json',{'status':state,'primary':summaries,'identical_text_policy':'One evaluation per unique text per patent, mapped to matching methods; ties are not independent judge votes.'})
    return rows,unique_rows,state
def run_tasks(client,cases,tasks,phase):
    errors=[];last=0
    with ThreadPoolExecutor(max_workers=client.config['workers']) as pool:
        futures={pool.submit(client.evaluate,c,v):(c,v) for c,v in tasks}
        for count,f in enumerate(as_completed(futures),1):
            c,v=futures[f]
            try:f.result()
            except Exception as exc:
                error={'language':c['language'],'publication_number':c['publication_number'],'variant':v,'type':type(exc).__name__,'message':str(exc)[:240]}
                errors.append(error);a.save(ROOT/'cases'/c['language']/c['publication_number']/v/'error.json',error)
                if isinstance(exc,(j.FatalError,AssertionError)):
                    client.stop.set()
                    for pending in futures:pending.cancel()
                    break
            if time.monotonic()-last>45 or count==len(tasks):
                _,_,state=collect(cases,phase+'_running');emit(event='judge_progress',done=count,total=len(tasks),errors=len(errors),completed=state['completed']);last=time.monotonic()
    a.save(ROOT/(phase+'_errors.json'),errors);return errors
def audit():
    a.verify_frozen()
    texts={a.METHODS[0]:'1. A sensor.',a.METHODS[1]:'1. A detector.',a.METHODS[2]:'1. A sensor.',a.METHODS[3]:'1. A sensor.'}
    unique,mapping=a.group_texts(texts);assert len(unique)==2 and mapping[a.METHODS[0]]==mapping[a.METHODS[2]]==mapping[a.METHODS[3]]
    cfg=a.read(ROOT/'config.json');c={'language':'en','publication_number':'SYNTHETIC','disclosure':'SYNTHETIC SOURCE START '+('A sensor detects light. '*10000)+' SOURCE END','reference':'1. A sensor.','drafts':unique,'method_groups':mapping}
    c['primary_order']=a.choose_order(c,Counter(),cfg['seed'])
    primary,labels=a.payload(cfg,c,'primary');reverse,rl=a.payload(cfg,c,'order_audit')
    data=json.loads(primary['input']['messages'][1]['content'])
    assert data['technical_disclosure']==c['disclosure'] and set(data['drafts'].values())==set(unique.values())
    assert list(labels.values())==list(reversed(list(rl.values())))
    assert all(m not in primary['input']['messages'][1]['content'] for m in a.METHODS)
    valid={label:{'Scores':{d:7 for d in a.DIMENSIONS},'Reasoning':'Supported sensor.','Support_Evidence':{'candidate_quote':'A sensor','disclosure_quote':'A sensor'}} for label in labels}
    assert set(j.parse(json.dumps(valid),list(labels)))==set(labels)
    bad=dict(valid,EXTRA=next(iter(valid.values())))
    try:j.parse(json.dumps(bad),list(labels))
    except ValueError:pass
    else:raise AssertionError('Extra key accepted')
    emit(event='judge_protocol_audit_pass',deduplication=True,full_input_preserved=True,blinding=True,order_swap=True,dynamic_schema=True,no_API_calls=True)
def report(cases,manifest,cfg):
    rows,unique,state=collect(cases,'finished');lookup={(r['language'],r['publication_number'],r['variant'],r['method']):r for r in rows}
    paired=[];orders=[]
    for lang in ['en','zh']:
        ids=sorted({r['publication_number'] for r in rows if r['language']==lang and r['variant']=='primary'})
        for other in a.METHODS[1:]:
            for dim in a.DIMENSIONS:
                diffs=np.array([lookup[lang,cid,'primary','full_der'][dim]-lookup[lang,cid,'primary',other][dim] for cid in ids])
                if not len(diffs):continue
                rng=np.random.default_rng(int(a.digest(f"{cfg['seed']}:{lang}:{other}:{dim}".encode())[:8],16))
                means=np.concatenate([diffs[rng.integers(0,len(ids),(500,len(ids)))].mean(axis=1) for _ in range(cfg['bootstrap_replicates']//500)])
                lo,hi=np.quantile(means,[.025,.975]);paired.append({'language':lang,'contrast':'full_der minus '+other,'dimension':dim,'n':len(ids),'delta_points':float(diffs.mean()),'ci95_low':float(lo),'ci95_high':float(hi),'same_text_pairs':sum(lookup[lang,cid,'primary','full_der']['text_sha256']==lookup[lang,cid,'primary',other]['text_sha256'] for cid in ids)})
        for m in a.METHODS:
            repeated=[cid for cid in ids if (lang,cid,'order_audit',m) in lookup]
            if not repeated:continue
            for dim in a.DIMENSIONS:
                delta=[lookup[lang,cid,'order_audit',m][dim]-lookup[lang,cid,'primary',m][dim] for cid in repeated]
                orders.append({'language':lang,'method':m,'dimension':dim,'n':len(delta),'mean_change':statistics.mean(delta),'mean_absolute_change':statistics.mean(map(abs,delta))})
    j.csv_save(ROOT/'paired_bootstrap.csv',paired);j.csv_save(ROOT/'order_sensitivity.csv',orders)
    missing=[{'language':c['language'],'publication_number':c['publication_number'],'variant':v} for c in cases for v in (['primary','order_audit'] if c['order_audit'] else ['primary']) if not (ROOT/'cases'/c['language']/c['publication_number']/v/'result.json').exists()]
    a.save(ROOT/'missing_judgments.json',missing)
    lines=['# 修正后消融：Qwen-Max 五维评价','',f'输入共同样本：{manifest["primary_target"]}；缺失裁判请求：{len(missing)}。分数1–10。', '同专利的完全相同文本只评一次并映射回条件；主评价与顺序审计分开，不将重复评分择优合并。','']
    summaries=a.read(ROOT/'summary.json')['primary']
    for lang in ['en','zh']:
        lines.extend([f'## {lang}','','| 条件 | n | FC | CC | TC | LL | OQ |','|---|---:|---:|---:|---:|---:|---:|'])
        for r in summaries:
            if r['language']==lang:lines.append('| '+r['method']+' | '+str(r['n'])+' | '+' | '.join(f'{r[d]:.3f}' for d in a.DIMENSIONS)+' |')
    lines.extend(['','配对差与点态95%区间见paired_bootstrap.csv；裁判顺序敏感性见order_sensitivity.csv。','Qwen-Max主线ID不是固定快照；这是同模型家族的模型评价，不是独立人类评审。引文可定位不等于完整语义验证。'])
    (ROOT/'RESULTS_CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    collect(cases,'complete' if not missing else 'finished_with_failures');return missing
def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['audit','prepare','pilot','run','report'],required=True);args=p.parse_args()
    if args.mode=='audit':audit();return
    if args.mode=='prepare':
        cfg,cases,manifest=a.prepare();emit(event='judge_inputs_frozen',patents=len(cases),unique_texts=manifest['unique_texts'],order_audit=manifest['order_audit_count'],no_API_calls=True);return
    cfg,cases,manifest=a.load()
    if args.mode=='report':report(cases,manifest,cfg);return
    sys.path.insert(0,str(ROOT.parent));import baseline_support as b
    client=j.Client(cfg,b.credential(cfg['credential_source']))
    if args.mode=='pilot':
        pilots=[c for c in cases if c['publication_number'] in cfg['pilot_ids'][c['language']]]
        errors=run_tasks(client,cases,[(c,'primary') for c in pilots],'pilot')
        _,unique,_=collect(cases,'pilot_finished');pilot_ids={(c['language'],c['publication_number']) for c in pilots}
        # Predeclared boundary probe: a historically overlength case remains in
        # the six requested pilots and full cohort, but its explicit context
        # rejection is a recorded missing judgment, not a broken transport.
        allowed=[]
        for error in errors:
            if error['publication_number'] not in cfg.get('pilot_expected_context_limit_ids',{}).get(error['language'],[]):continue
            directory=ROOT/'cases'/error['language']/error['publication_number']/'primary'
            records=[a.read(p) for p in directory.glob('attempt_*.json')]
            if any(r.get('status')=='api_error' and r.get('status_code')==400 and r.get('code')=='InvalidParameter' and 'input length' in r.get('api_message','').lower() for r in records):allowed.append(error)
        exempt={(e['language'],e['publication_number']) for e in allowed}
        scored=[r for r in unique if (r['language'],r['publication_number']) in pilot_ids and r['variant']=='primary'];expected=sum(len(c['drafts']) for c in pilots if (c['language'],c['publication_number']) not in exempt)
        trace=statistics.mean(r['candidate_quote_found'] and r['disclosure_quote_found'] for r in scored) if scored else 0
        gate={'passed':len(errors)==len(allowed) and len(pilots)-len(exempt)>=5 and len(scored)==expected and trace>=.8,'patents_requested':len(pilots),'patents_expected_scored':len(pilots)-len(exempt),'unique_texts_expected':expected,'unique_texts_scored':len(scored),'quote_traceable_rate':trace,'errors':errors,'expected_context_rejections':allowed,'scores_used_for_gate':False,'gate':'Schema/completion and >=80% literal quote traceability; one predeclared historically overlength boundary probe may be missing only on API400 InvalidParameter input-length rejection. No score/rank gate.'}
        a.save(ROOT/'pilot_validation.json',gate);emit(event='judge_pilot_finished',**gate);sys.exit(0 if gate['passed'] else 2)
    assert a.read(ROOT/'pilot_validation.json')['passed']
    tasks=[(c,'primary') for c in cases]+[(c,'order_audit') for c in cases if c['order_audit']]
    tasks.sort(key=lambda cv:a.digest(f"{cfg['seed']}:{cv[0]['language']}:{cv[0]['publication_number']}:{cv[1]}:dispatch".encode()))
    run_tasks(client,cases,tasks,'full');missing=report(cases,manifest,cfg);emit(event='judge_finished',missing=len(missing));sys.exit(0 if not missing else 2)
if __name__=='__main__':main()
