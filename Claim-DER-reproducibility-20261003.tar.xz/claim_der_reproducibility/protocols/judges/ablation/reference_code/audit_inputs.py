"""Frozen four-condition inputs with exact-text deduplication and blinded ordering."""
import hashlib,itertools,json,random,sys
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
METHODS=['full_der','generic_feedback','full_disclosure','free_reviser']
DIMENSIONS=['Feature_Completeness','Conceptual_Clarity','Terminology_Consistency','Logical_Linkage','Overall_Quality']
LABELS=['Draft_'+x for x in 'ABCD']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(data):return hashlib.sha256(data).hexdigest()
def save(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(p.suffix+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');temp.replace(p)
def payload(config,case,variant):
    order=case['primary_order'] if variant=='primary' else list(reversed(case['primary_order']))
    aliases=dict(zip(LABELS,order))
    data={'language':{'en':'English','zh':'Chinese'}[case['language']],'technical_disclosure':case['disclosure'],'published_reference_claims':case['reference'],'drafts':{label:case['drafts'][key] for label,key in aliases.items()}}
    params={'result_format':'message','temperature':config['temperature'],'seed':int(digest(f"{config['seed']}:{case['language']}:{case['publication_number']}:judge".encode())[:8],16)%2147483647,'max_tokens':config['max_tokens'],'response_format':{'type':'json_object'}}
    return {'model':config['model'],'input':{'messages':[{'role':'system','content':(ROOT/'rubric.txt').read_text(encoding='utf-8')},{'role':'user','content':json.dumps(data,ensure_ascii=False)}]},'parameters':params},aliases
def group_texts(texts):
    unique={};mapping={}
    for method,text in texts.items():
        key=digest(text.encode());assert key not in unique or unique[key]==text
        unique[key]=text;mapping[method]=key
    return unique,mapping
def choose_order(case,counts,seed):
    keys=sorted(case['drafts']);n=len(keys);perms=list(itertools.permutations(keys))
    random.Random(f"{seed}:{case['language']}:{case['publication_number']}:positions").shuffle(perms)
    def cost(order):
        score=0
        for method,key in case['method_groups'].items():
            position=order.index(key)
            score+=2*counts[(n,method,position)]+1
        return score
    order=list(min(perms,key=cost))
    for method,key in case['method_groups'].items():counts[(n,method,order.index(key))]+=1
    return order
def verify_frozen():
    for name,h in read(ROOT/'JUDGE_FROZEN.json')['files'].items():assert digest((ROOT/name).read_bytes())==h,'Judge protocol drift'
def prepare():
    verify_frozen();cfg=read(ROOT/'config.json');generation=Path(cfg['generation_run']);gcfg=read(generation/'config.json');selection=read(generation/'selection.json')
    assert (generation/'correction_reconciliation.json').exists()
    if (ROOT/'input_manifest.json').exists():return load()
    cases=[];hashes={};missing=[];audit={'languages':{}}
    for lang,suffix in [('en','english'),('zh','chinese')]:
        inp=Path(gcfg['dataset'])/'data'/(suffix+'_1000.json');hashes[str(inp)]=digest(inp.read_bytes())
        assert hashes[str(inp)]==selection['source_hashes'][lang]
        idx={r['publication_number']:r for r in read(inp)};outputs={}
        for m in METHODS:
            p=generation/'results'/(lang+'_'+m+'.json');hashes[str(p)]=digest(p.read_bytes());outputs[m]={r['publication_number']:r['text'] for r in read(p)}
        ids=sorted(set.intersection(*(set(x) for x in outputs.values())));assert set(ids)<=set(selection['selected_ids'][lang])
        missing.extend({'language':lang,'publication_number':cid,'missing_methods':[m for m in METHODS if cid not in outputs[m]]} for cid in sorted(set(selection['selected_ids'][lang])-set(ids)))
        counts=Counter();group=[]
        for cid in ids:
            drafts,method_groups=group_texts({m:outputs[m][cid] for m in METHODS})
            case={'language':lang,'publication_number':cid,'disclosure':idx[cid]['draft_description'],'reference':idx[cid]['published_claim'],'drafts':drafts,'method_groups':method_groups}
            assert all(isinstance(s,str) and s.strip() for s in [case['disclosure'],case['reference'],*drafts.values()])
            case['primary_order']=choose_order(case,counts,cfg['seed']);group.append(case)
        eligible=sorted([c['publication_number'] for c in group if len(c['drafts'])>1],key=lambda cid:digest(f"{cfg['seed']}:{lang}:{cid}:order_audit".encode()))
        audit_ids=eligible[:cfg['order_audit_per_language']]
        for c in group:c['order_audit']=c['publication_number'] in audit_ids
        pilots=cfg['pilot_ids'][lang];assert set(pilots)<=set(ids),'Predetermined pilot has missing generation'
        cases.extend(group)
        audit['languages'][lang]={'common_patents':len(group),'unique_texts':sum(len(c['drafts']) for c in group),'unique_count_distribution':dict(Counter(len(c['drafts']) for c in group)),'pilot_ids':pilots,'order_audit_ids':audit_ids,'position_counts':[{'unique_count':n,'method':m,'position':p+1,'count':v} for (n,m,p),v in sorted(counts.items())]}
    save(ROOT/'cases_manifest.json',cases)
    manifest={'generation_run':str(generation),'source_hashes':hashes,'cases_manifest_sha256':digest((ROOT/'cases_manifest.json').read_bytes()),'missing_generation':missing,'primary_target':{l:audit['languages'][l]['common_patents'] for l in ['en','zh']},'case_count':len(cases),'unique_texts':sum(len(c['drafts']) for c in cases),'order_audit_count':sum(c['order_audit'] for c in cases),'blinding':'No method names in prompts; exact text deduplicated per patent; greedy balanced positions within each unique-count stratum, seeded tie breaking; reverse-order audit.'}
    save(ROOT/'input_manifest.json',manifest);save(ROOT/'input_audit.json',audit)
    return cfg,cases,manifest
def load():
    verify_frozen();cfg=read(ROOT/'config.json');manifest=read(ROOT/'input_manifest.json')
    for path,h in manifest['source_hashes'].items():assert digest(Path(path).read_bytes())==h,'Frozen generation output changed'
    assert digest((ROOT/'cases_manifest.json').read_bytes())==manifest['cases_manifest_sha256']
    return cfg,read(ROOT/'cases_manifest.json'),manifest
