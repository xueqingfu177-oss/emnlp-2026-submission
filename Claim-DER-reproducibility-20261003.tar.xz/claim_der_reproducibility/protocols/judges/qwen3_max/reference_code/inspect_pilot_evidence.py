"""Inspect quote failures without looking at system scores or rankings."""
import difflib
import gzip
import json
from pathlib import Path
from run_judge import normalize

root=Path(__file__).resolve().parent
rows=[]
for path in sorted((root/'cases').glob('*/*/primary/result.json')):
    result=json.loads(path.read_text())
    with gzip.open(path.parent/'request.json.gz','rt',encoding='utf-8') as f:
        request=json.load(f)
    data=json.loads(request['input']['messages'][1]['content'])
    for label,method in result['mapping'].items():
        flags=result['evidence_audit'][method]
        if flags['candidate_quote_found'] and flags['disclosure_quote_found']:continue
        evidence=result['evaluation'][label]['Support_Evidence']
        row={'language':result['language'],'id':result['publication_number'],'alias':label,'flags':flags,'evidence':evidence}
        for key,source in [('candidate_quote',data['drafts'][label]),('disclosure_quote',data['technical_disclosure'])]:
            quote=normalize(evidence[key]);source=normalize(source)
            if quote and quote not in source:
                match=difflib.SequenceMatcher(None,quote,source,autojunk=False).find_longest_match(0,len(quote),0,len(source))
                row[key+'_closest_context']=source[max(0,match.b-80):match.b+match.size+80]
        rows.append(row)
print(json.dumps({'failed_quote_pairs':rows,'status':json.loads((root/'status.json').read_text())},ensure_ascii=False,indent=2))
