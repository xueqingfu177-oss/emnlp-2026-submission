"""Official BERTScore with pinned default models and explicit truncation audit.

Only saved candidate/reference claims are evaluated. No model-generation API.
"""
import os
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
import argparse
import csv
import gc
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import statistics
import sys
import time

import numpy as np
import torch
from bert_score import BERTScorer
from bert_score.utils import get_hash, sent_encode

METHODS = ['ft_llama3', 'qwen_turbo', 'qwen_max', 'self_refine', 'implicit_cot', 'plangen_bon5', 'claim_der']
METRICS = ['BERT_P', 'BERT_R', 'BERT_F1']
REV_EN = '722cf37b1afa9454edce342e7895e588b6ff1d59'
REV_ZH = '8f23c25b06e129b6c986331a13d8d025a92cf0ea'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, obj):
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def csv_write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def normalize(text):
    return re.sub(r'\s+', ' ', text).strip()


def summarize(dest, rows, protocol):
    summaries, paired = [], []
    for lang in ['en', 'zh']:
        if not any(x['language'] == lang for x in rows):
            continue
        for cohort in ['common7', 'all_available']:
            for method in METHODS:
                group = [x for x in rows if x['language'] == lang and x['method'] == method
                         and (cohort == 'all_available' or x['on_common7'])]
                if not group:
                    continue
                result = {'language':lang, 'cohort':cohort, 'method':method, 'n':len(group)}
                result.update({key:100*statistics.mean(x[key] for x in group) for key in METRICS})
                result.update({'prediction_truncated_pct':100*statistics.mean(x['prediction_full_tokens'] > x['prediction_used_tokens'] for x in group),
                               'reference_truncated_pct':100*statistics.mean(x['reference_full_tokens'] > x['reference_used_tokens'] for x in group),
                               'prediction_mean_coverage_pct':100*statistics.mean(x['prediction_used_tokens']/max(1,x['prediction_full_tokens']) for x in group),
                               'reference_mean_coverage_pct':100*statistics.mean(x['reference_used_tokens']/max(1,x['reference_full_tokens']) for x in group)})
                summaries.append(result)
        by = {(x['publication_number'],x['method']):x for x in rows if x['language'] == lang and x['on_common7']}
        ids = sorted({cid for cid,m in by})
        for baseline in [x for x in METHODS if x not in ['claim_der','ft_llama3']]:
            for metric in METRICS:
                delta = np.array([(by[(cid,'claim_der')][metric]-by[(cid,baseline)][metric])*100 for cid in ids])
                rng = np.random.default_rng(int(hashlib.sha256(f'20260930:{lang}:{metric}:{baseline}'.encode()).hexdigest()[:8],16))
                samples = np.concatenate([delta[rng.integers(0,len(delta),size=(500,len(delta)))].mean(axis=1) for _ in range(40)])
                lo,hi = np.quantile(samples,[.025,.975])
                ours = statistics.mean(by[(cid,'claim_der')][metric] for cid in ids)
                base = statistics.mean(by[(cid,baseline)][metric] for cid in ids)
                paired.append({'language':lang,'metric':metric,'baseline':baseline,'n':len(ids),
                               'delta_pp':float(delta.mean()),'relative_gain_pct':100*(ours/base-1),
                               'ci95_low_pp':float(lo),'ci95_high_pp':float(hi)})
    csv_write(dest/'automatic_metrics.csv', summaries)
    csv_write(dest/'paired_bootstrap.csv', paired)
    save(dest/'summary.json', {'protocol':protocol,'rows':summaries})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    root = args.run.resolve()
    sys.path.insert(0,str(root))
    import run_baselines as runner
    config = read(root/'config.json')
    runner.load_inputs(config)
    dest = root/('bertscore_smoke_20260930' if args.smoke else 'bertscore_20260930')
    dest.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.set_num_interop_threads(2)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.cuda.set_per_process_memory_fraction(.055, 0)
    start = time.monotonic()
    protocol = {'implementation':'bert_score.BERTScorer.score',
                'packages':{p:importlib.metadata.version(p) for p in ['bert-score','transformers','torch']},
                'idf':False, 'rescale_with_baseline':False, 'use_fast_tokenizer':False,
                'dtype':'float32', 'device':'cuda:0', 'batch_size':1,
                'normalization':'Collapse all whitespace runs to one space and strip, for all languages and methods.',
                'truncation':'Official tokenizer maximum 512 tokens including 2 special tokens; right-truncated to 510 content tokens. Scores do NOT evaluate the whole claim set when longer.',
                'bootstrap':'20000 paired patent-ID resamples; seed 20260930 hashed by language/metric/baseline; pointwise 95% CIs, exploratory, no multiple-comparison or family correction.',
                'script_sha256':sha(Path(__file__)), 'models':{}, 'input_hashes':{},
                'smoke_only':args.smoke}
    rows = []
    for lang,name,model_id,layers,revision in [('en','english','roberta-large',17,REV_EN), ('zh','chinese','bert-base-chinese',8,REV_ZH)]:
        model_path = (Path.home()/'.cache/huggingface/hub/models--roberta-large/snapshots')/revision if lang == 'en' else root/'metric_models/bert-base-chinese'/revision
        assert (model_path/'model.safetensors').exists()
        scorer = BERTScorer(model_type=str(model_path), num_layers=layers, lang=lang, idf=False,
                            rescale_with_baseline=False, use_fast_tokenizer=False, device='cuda:0', batch_size=1)
        assert scorer._tokenizer.model_max_length == 512
        protocol['models'][lang] = {'model':model_id,'revision':revision,'num_layers':layers,
                                   'hash':get_hash(model_id,layers,False,False,False,False),
                                   'model_safetensors_sha256':sha(model_path/'model.safetensors')}
        source = Path(config['dataset'])/'data'/f'{name}_1000.json'
        protocol['input_hashes'][str(source)] = sha(source)
        frozen = sorted(read(source), key=lambda x:x['publication_number'])
        outputs = {}
        for method in METHODS:
            path = root/'results'/f'{lang}_{method}.json'
            protocol['input_hashes'][str(path)] = sha(path)
            content = read(path)
            outputs[method] = {x['publication_number']:x['text'] for x in content}
            assert len(outputs[method]) == len(content)
        common = set.intersection(*(set(x) for x in outputs.values()))
        assert len(common) == (990 if lang == 'en' else 992)
        if args.smoke:
            frozen = [x for x in frozen if x['publication_number'] in sorted(common)[:2]]
        jobs = []
        counts = {}
        def token_counts(text):
            if text not in counts:
                kwargs = {'add_prefix_space':True} if lang == 'en' else {}
                full = scorer._tokenizer.encode(text, add_special_tokens=False, truncation=False, **kwargs)
                used = len(sent_encode(scorer._tokenizer,text))-2
                assert used == min(len(full),510)
                counts[text] = (len(full),used)
            return counts[text]
        for case in frozen:
            cid = case['publication_number']
            reference = normalize(case['published_claim'])
            ref_full,ref_used = token_counts(reference)
            for method in METHODS:
                if cid not in outputs[method]:
                    continue
                prediction = normalize(outputs[method][cid])
                pred_full,pred_used = token_counts(prediction)
                jobs.append(({'language':lang,'publication_number':cid,'method':method,'on_common7':cid in common,
                              'reference_full_tokens':ref_full,'reference_used_tokens':ref_used,
                              'prediction_full_tokens':pred_full,'prediction_used_tokens':pred_used},reference,prediction))
        save(dest/'protocol.json',protocol)
        language_rows = []
        for offset in range(0,len(jobs),70):
            batch = jobs[offset:offset+70]
            values = scorer.score([x[2] for x in batch], [x[1] for x in batch], batch_size=1)
            for i,(record,_,_) in enumerate(batch):
                record.update({key:float(values[j][i]) for j,key in enumerate(METRICS)})
                assert all(np.isfinite(record[key]) for key in METRICS)
                language_rows.append(record)
            # Persist completed batches; publication IDs remain frozen.
            csv_write(dest/f'{lang}_per_case_metrics.csv',language_rows)
            progress = {'phase':'running', 'language':lang,'completed':len(language_rows),'total':len(jobs),
                        'seconds':time.monotonic()-start,'peak_gpu_allocated_mib':torch.cuda.max_memory_allocated()/2**20}
            save(dest/'status.json',progress)
            if offset % 700 == 0:
                print(json.dumps(progress),flush=True)
        rows.extend(language_rows)
        del scorer
        gc.collect()
        torch.cuda.empty_cache()
    csv_write(dest/'per_case_metrics.csv',rows)
    summarize(dest,rows,protocol)
    save(dest/'status.json',{'phase':'complete','n_scored':len(rows),'seconds':time.monotonic()-start,'smoke_only':args.smoke})
    print(json.dumps(read(dest/'status.json')),flush=True)


if __name__ == '__main__':
    main()
