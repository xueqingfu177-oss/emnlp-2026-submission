"""Rebuild table values from saved per-patent scores; no API, GPU or NLP dependencies."""
import argparse
import csv
import json
import math
from pathlib import Path
from statistics import mean

ROOT=Path(__file__).resolve().parent
METHODS=['ft_llama3','qwen_turbo','qwen_max','self_refine','implicit_cot','plangen_bon5','claim_der']
ABL=['draft_only','full_der','generic_feedback','full_disclosure','free_reviser']
DIMS=['Feature_Completeness','Conceptual_Clarity','Terminology_Consistency','Logical_Linkage','Overall_Quality']
checks=[]
def read(rel):
    with (ROOT/'scores'/rel).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def check(label,a,b):
    if b in ['',None]: assert a is None,(label,a,b)
    else: assert a is not None and math.isclose(a,float(b),rel_tol=1e-10,abs_tol=1e-8),(label,a,b)
    checks.append(label)
def average(rows,key,scale=100):
    values=[float(r[key]) for r in rows if r.get(key) not in ['',None]]
    assert all(math.isfinite(x) for x in values)
    return (scale*mean(values) if values else None),len(values)
def save(path,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def summaries(folder,percase,expected,keys,cohort='common7',flag='on_common7',methods=METHODS):
    rows=read(folder+'/'+percase); exp=read(folder+'/'+expected);result={}
    for lang in ['en','zh']:
        for method in methods:
            group=[r for r in rows if r['language']==lang and r['method']==method and r.get(flag)=='True']
            assert len({r['publication_number'] for r in group})==len(group)
            e=next(r for r in exp if r['language']==lang and r['method']==method and r.get('cohort',cohort)==cohort)
            result[lang,method]={'language':lang,'method':method,'n':len(group)}
            for key in keys:
                value,n=average(group,key)
                check(f'{folder}/{lang}/{method}/{key}',value,e[key])
                if key+'_n' in e:check(f'{folder}/{lang}/{method}/{key}_n',n,e[key+'_n'])
                result[lang,method].update({key:value,key+'_n':n})
    return result
def judges(folder,methods):
    rows=[r for r in read(folder+'/per_case_scores.csv') if r['variant']=='primary']
    exp=read(folder+'/summary_scores.csv'); result={}
    for lang in ['en','zh']:
        ids=set.intersection(*[{r['publication_number'] for r in rows if r['language']==lang and r['method']==m} for m in methods])
        for method in methods:
            group=[r for r in rows if r['language']==lang and r['method']==method and r['publication_number'] in ids]
            assert len(group)==len(ids)
            e=next(r for r in exp if r['language']==lang and r['method']==method)
            check(f'{folder}/{lang}/{method}/n',len(group),e['n'])
            result[lang,method]={'language':lang,'method':method,'judge_n':len(group)}
            for key in DIMS:
                value,n=average(group,key,1)
                check(f'{folder}/{lang}/{method}/{key}',value,e[key]);result[lang,method][key]=value
    return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=ROOT/'rebuilt');a=p.parse_args()
    out=a.output;out.mkdir(parents=True,exist_ok=True)
    par=summaries('main/par','per_case_metrics.csv','automatic_metrics.csv',['RG_legacy','RG_jieba','PAR_head','PAR_mid','PAR_tail'])
    rouge=summaries('main/rouge','per_case_metrics.csv','automatic_metrics.csv',[f'{k}_{s}' for k in ['R1','R2','RL'] for s in ['P','R','F1']])
    bert=summaries('main/bertscore','per_case_metrics.csv','automatic_metrics.csv',['BERT_P','BERT_R','BERT_F1'])
    darrows=read('main/dar/en_per_case.csv')+read('main/dar/zh_per_case.csv');darexp=read('main/dar/automatic_metrics.csv');dar={}
    structure=read('main/structure/per_case.csv');structure_exp=read('main/structure/summary.csv');surface=[]
    for lang in ['en','zh']:
        for method in METHODS:
            group=[r for r in darrows if r['language']==lang and r['method']==method and r['on_common7']=='True']
            den=sum(int(r['reference_eligible_nodes']) for r in group);num=sum(int(r['numerator_nodes']) for r in group)
            e=next(r for r in darexp if r['language']==lang and r['method']==method and r['cohort']=='common7')
            value=100*num/den if den else None
            check(f'DAR/{lang}/{method}',value,e['DAR']);check(f'DAR/{lang}/{method}/nodes',den,e['denominator_nodes'])
            dar[lang,method]={'DAR':value,'DAR_nodes':den,'DAR_patents':sum(int(r['reference_eligible_nodes'])>0 for r in group)}
            group=[r for r in structure if r['language']==lang and r['method']==method and r['on_common7']=='True']
            parsed=[r for r in group if r['parseable']=='True'];passed=sum(r['pass']=='True' for r in group)
            edge_n=sum(int(r['edges']) for r in parsed)
            values={'language':lang,'method':method,'n':len(group),'parsed_n':len(parsed),
                    'parseable_pct':100*len(parsed)/len(group),'pass_all_pct':100*passed/len(group),
                    'pass_parsed_pct':100*passed/len(parsed) if parsed else None,
                    'invalid_reference_pct':100*sum(int(r['invalid_edges']) for r in parsed)/edge_n if edge_n else None}
            e=next(r for r in structure_exp if r['language']==lang and r['method']==method)
            for k in ['n','parsed_n','parseable_pct','pass_all_pct','pass_parsed_pct','invalid_reference_pct']:check(f'structure/{lang}/{method}/{k}',values[k],e[k])
            surface.append(values)
    qm=judges('main/qwen_max',METHODS);q3=judges('main/qwen3_max',METHODS)
    table1=[];table2=[]
    for key,r in rouge.items():
        lang,method=key
        check(f'common cohort/{lang}/{method}',r['n'],990 if lang=='en' else 992)
        # Paper's Chinese RG uses Jieba, not the legacy ASCII tokenizer.
        rg=par[key]['RG_legacy' if lang=='en' else 'RG_jieba']
        check(f'RG versus ROUGE-L/{lang}/{method}',rg,r['RL_R'])
        table1.append({'language':lang,'method':method,'automatic_n':r['n'],'RG':rg,**{k:v for k,v in qm[key].items() if k not in ['language','method']}})
        table2.append({'language':lang,'method':method,'automatic_n':r['n'],'R1_R':r['R1_R'],'R2_R':r['R2_R'],
            **{k:v for k,v in par[key].items() if k.startswith('PAR_')},**dar[key]})
    ab=summaries('ablation/automatic','per_case_metrics.csv','automatic_metrics.csv',
        [f'{k}_{s}' for k in ['R1','R2','RL'] for s in ['P','R','F1']]+['PAR_head','PAR_mid','PAR_tail','surface_pass','claim1_same','draft_token_retention'],
        'common4','on_common4',ABL)
    aj=judges('ablation/judge',ABL[1:])
    for key,r in ab.items():
        check(f'ablation cohort/{key}',r['n'],197 if key[0]=='en' else 199)
        if key in aj:r.update({k:v for k,v in aj[key].items() if k not in ['language','method']})
    for name,rows in [('table1_main',table1),('table2_main',table2),('supplement_rouge',list(rouge.values())),
        ('supplement_bertscore',list(bert.values())),('supplement_structure',surface),('supplement_qwen3max',list(q3.values())),('ablation',list(ab.values()))]:save(out/(name+'.csv'),rows)
    report={'passed':True,'numeric_checks':len(checks),'api_calls':0,'scope':'Means, denominators and main/supplement/ablation table values rebuilt from per-patent records. Archived bootstrap/correlation tables are supplied separately, not recomputed by this command.'}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))
if __name__=='__main__':main()
