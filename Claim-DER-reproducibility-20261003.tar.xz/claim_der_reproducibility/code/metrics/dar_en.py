import re
import spacy

nlp = spacy.load("en_core_web_sm")

def parse_claims(text):
    """解析权利要求树结构"""
    claims = {}
    if not text: return claims
    pattern = re.compile(r'\b(\d+)\.\s+(.*?)(?=\b\d+\.\s+|$)', re.DOTALL)
    matches = pattern.findall(text)
    for match in matches:
        cid = int(match[0])
        content = match[1].strip()
        parent_match = re.search(r'claim\s+(\d+)', content, re.IGNORECASE)
        parent_id = int(parent_match.group(1)) if parent_match else 0
        claims[cid] = {"text": content, "parent": parent_id}
    return claims

def extract_explicit_entities(text):
    """提取显式前置基础实体"""
    doc = nlp(text.lower())
    introduced, referenced = set(), set()
    for chunk in doc.noun_chunks:
        words = chunk.text.split()
        if not words: continue
        core_noun = words[-1] if words[-1].isalpha() else ""
        if not core_noun: continue
        first_word = words[0]
        if first_word in ['a', 'an']:
            introduced.add(core_noun)
        elif first_word in ['the', 'said']:
            referenced.add(core_noun)
    return introduced, referenced

def get_node_health_status(text):
    """
    节点级健康体检：返回每个 Claim 编号是否是“健康的”
    （即该节点内所有的 the/said 都能在合法的前置基础池中找到）
    """
    health_status = {}
    claims = parse_claims(text)
    if not claims: return health_status

    history_entities = {0: set()}

    for cid in sorted(claims.keys()):
        info = claims[cid]
        parent_id = info["parent"]
        inherited = set(history_entities.get(parent_id, set()))
        intro, ref = extract_explicit_entities(info["text"])

        current_valid_pool = inherited.union(intro)

        is_healthy = True
        for r in ref:
            if r not in current_valid_pool:
                is_healthy = False
                break

        health_status[cid] = is_healthy
        history_entities[cid] = current_valid_pool

    return health_status
