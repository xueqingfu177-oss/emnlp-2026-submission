import re
from collections import Counter
import nltk
from nltk.corpus import stopwords
import jieba.analyse

def extract_chinese_keywords(text, top_k):
    """提取中文核心特征词 (引入 jieba TF-IDF 算法，提取质量远超词频统计)"""
    if not text: return []
    # 仅允许提取名词(n)、名动词(vn)、动词(v)、专有名词(nz)、英文(eng，针对专利中的字母缩写)
    allowed_pos = ('n', 'vn', 'v', 'nz', 'eng')
    # jieba.analyse 自带内部的中文停用词表过滤
    keywords = jieba.analyse.extract_tags(text, topK=top_k, allowPOS=allowed_pos)
    return keywords

def map_features_to_positions(features, disclosure_text):
    """
    【核心逻辑】将提取的特征词映射回原文(Disclosure)，
    并按其首次出现的相对位置分桶: Head (0-33%), Middle (33-66%), Tail (>66%)
    """
    head_feats, mid_feats, tail_feats = [], [], []
    if not disclosure_text:
        return head_feats, mid_feats, tail_feats

    # 转小写是为了兼容专利中出现的英文缩写
    disclosure_lower = disclosure_text.lower()
    total_len = len(disclosure_lower)

    for kw in features:
        kw_lower = kw.lower()
        # 中文没有明显的单词边界，不能用 \b 正则匹配，直接使用 find 找子串位置
        match_idx = disclosure_lower.find(kw_lower)

        if match_idx != -1:
            rel_pos = match_idx / total_len
            if rel_pos < 0.333:
                head_feats.append(kw)
            elif rel_pos < 0.666:
                mid_feats.append(kw)
            else:
                tail_feats.append(kw)
        else:
            # 如果原文找不到该词，则丢弃，保证分母严谨
            pass

    return head_feats, mid_feats, tail_feats
