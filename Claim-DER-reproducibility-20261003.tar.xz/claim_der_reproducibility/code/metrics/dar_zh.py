import re
import spacy

nlp = spacy.load("zh_core_web_sm")

def parse_claims(text):
    """解析中文权利要求树结构 (修复正则空格Bug)"""
    claims = {}
    if not text: return claims
    # 兼容: "1.", "1、", "1．" 且不强求后面有空格
    pattern = re.compile(r'(?:^|\n)\s*(\d+)[\.．、]\s*(.*?)(?=(?:^|\n)\s*\d+[\.．、]|$)', re.DOTALL)
    matches = pattern.findall(text)

    for match in matches:
        cid = int(match[0])
        content = match[1].strip()
        # 兼容: "如权利要求1所述" 或 "权利要求 1"
        parent_match = re.search(r'权利要求\s*[\(（]?\s*(\d+)\s*[\)）]?', content)
        parent_id = int(parent_match.group(1)) if parent_match else 0
        claims[cid] = {"text": content, "parent": parent_id}
    return claims

def extract_explicit_entities(text):
    """提取显式前置基础实体 (修复中文复合名词切分Bug)"""
    if not text: return set(), set()
    doc = nlp(text)
    introduced, referenced = set(), set()

    ref_kws = {'所述', '该', '前述', '本'}
    valid_noun_tags = {'NN', 'NR', 'NOUN', 'PROPN'}  # 增加兼容性

    i = 0
    while i < len(doc):
        token = doc[i]

        # --- 逻辑 1：检测引用实体 (贪婪吸收后续名词) ---
        if token.text in ref_kws:
            j = i + 1
            entity_parts = []
            # 一直往后找，直到不是名词或形容词为止 (例如完美拼接: 石墨烯 + 源端 + 电极)
            while j < len(doc) and doc[j].pos_ in {'NN', 'NR', 'ADJ', 'NOUN', 'PROPN'}:
                entity_parts.append(doc[j].text)
                j += 1

            if entity_parts:
                referenced.add("".join(entity_parts))
            i = j  # 核心：指针直接跳过已经吸收的组合词
            continue

        # --- 逻辑 2：检测引入实体 (新名词) ---
        if token.pos_ in valid_noun_tags and len(token.text) > 1:
            introduced.add(token.text)

        i += 1

    return introduced, referenced

def get_node_health_status(text):
    health_status = {}
    claims = parse_claims(text)
    if not claims: return health_status
    history_entities = {0: set()}

    for cid in sorted(claims.keys()):
        info = claims[cid]
        parent_id = info["parent"]
        inherited = set(history_entities.get(parent_id, set()))
        intro, ref = extract_explicit_entities(info["text"])

        current_valid_pool = inherited.union(intro)

        is_healthy = True
        for r in ref:
            # 只要有一个引用的实体没在合法池里，这个节点就违法了
            if r not in current_valid_pool:
                is_healthy = False
                break

        health_status[cid] = is_healthy
        history_entities[cid] = current_valid_pool

    return health_status
