from collections import Counter

def lcs_count(reference, prediction):
    masks = {}
    for i, token in enumerate(reference):
        masks[token] = masks.get(token, 0) | (1 << i)
    state = 0
    for token in prediction:
        x = state | masks.get(token, 0)
        state = x & ~(x - ((state << 1) | 1))
    return bin(state).count('1')

def prf(matches, reference_n, prediction_n):
    precision = matches / prediction_n if prediction_n else 0.0
    recall = matches / reference_n if reference_n else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return precision, recall, f1

def ngrams(tokens, n):
    return Counter(tuple(tokens[i:i+n]) for i in range(len(tokens)-n+1))

def metrics(reference, prediction):
    result = {}
    for n in [1, 2]:
        a, b = ngrams(reference, n), ngrams(prediction, n)
        result.update(zip([f'R{n}_{p}' for p in ['P', 'R', 'F1']],
                          prf(sum((a & b).values()), sum(a.values()), sum(b.values()))))
    result.update(zip(['RL_P', 'RL_R', 'RL_F1'],
                      prf(lcs_count(reference, prediction), len(reference), len(prediction))))
    return result
