import re
from collections import Counter
import nltk
from nltk.corpus import stopwords
import jieba.analyse

def extract_english_keywords(text, top_k):
    """提取英文核心特征词"""
    if not text: return []
    text = text.lower()
    tokens = nltk.word_tokenize(text)
    tagged_tokens = nltk.pos_tag(tokens)
    stop_words = set(stopwords.words('english'))
    valid_tags = ('NN', 'NNS', 'NNP', 'NNPS', 'VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ')

    valid_words = [word for word, tag in tagged_tokens if
                   word.isalpha() and word not in stop_words and tag in valid_tags]
    word_counts = Counter(valid_words)
    return [word for word, count in word_counts.most_common(top_k)]

def map_features_to_positions(features, disclosure_text):
    """将特征词按其在原文(Disclosure)首次出现的相对位置分桶"""
    head_feats, mid_feats, tail_feats = [], [], []
    if not disclosure_text:
        return head_feats, mid_feats, tail_feats

    disclosure_lower = disclosure_text.lower()
    total_len = len(disclosure_lower)

    for kw in features:
        match = re.search(r'\b' + re.escape(kw) + r'\b', disclosure_lower)
        if match:
            rel_pos = match.start() / total_len
            if rel_pos < 0.333:
                head_feats.append(kw)
            elif rel_pos < 0.666:
                mid_feats.append(kw)
            else:
                tail_feats.append(kw)
    return head_feats, mid_feats, tail_feats
