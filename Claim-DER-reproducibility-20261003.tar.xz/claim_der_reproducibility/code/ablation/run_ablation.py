"""Frozen paired ablations. Generation has disclosures, never reference claims."""
import argparse, gzip, hashlib, json, os, random, re, sys, threading, time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import baseline_support as b
import prompts
import structure_support

HERE=Path(__file__).resolve().parent
VARIANTS=["full_der","generic_feedback","full_disclosure","free_reviser"]
def sha_file(p):return b.sha(Path(p).read_bytes())
def verify_frozen():
    frozen=b.read(HERE/"PROTOCOL_FROZEN.json")
    for name,digest in frozen["files"].items():
        assert sha_file(HERE/name)==digest, "Frozen artifact changed: "+name
    return frozen
def load_cases(config):
    selection=b.read(HERE/"selection.json")
    assert sha_file(HERE/"selection.json")==config["selection_sha256"]
    cases=[]
    for lang,suffix in [("en","english"),("zh","chinese")]:
        p=Path(config["dataset"])/"data"/(suffix+"_1000.json")
        assert sha_file(p)==selection["source_hashes"][lang], "Dataset hash drift"
        rows=b.read(p);index={r["publication_number"]:r for r in rows}
        assert len(index)==len(rows)==1000
        ids=selection["selected_ids"][lang]
        assert len(ids)==len(set(ids))==200 and set(ids)<=set(index)
        for cid in ids:
            assert re.fullmatch(r"[A-Za-z0-9_-]+",cid)
            cases.append({"language":lang,"publication_number":cid,"disclosure":index[cid]["draft_description"]})
    return cases,selection
def legacy_skip(text):return text.strip().upper()=="NONE"
def clean(text):
    fence=chr(96)*3
    return re.sub("^"+fence+r"(?:text|plaintext)?\s*|\s*"+fence+"$","",text.strip()).strip()
def prompt_audit():
    d="DISCLOSURE_SENTINEL";draft="1. A sensor.";fb="Add a dependent claim."
    for language in ["en","zh"]:
        base=prompts.revision_prompt("full_der",d,draft,fb,language)
        src=prompts.revision_prompt("full_disclosure",d,draft,fb,language)
        free=prompts.revision_prompt("free_reviser",d,draft,fb,language)
        generic=prompts.revision_prompt("generic_feedback",d,draft,fb,language)
        assert base==generic
        assert src[0]==base[0] and src[1]["content"]==base[1]["content"]+"\n[Technical Disclosure]:\n"+d
        assert all(d not in m["content"] for m in base+free)
        assert "95%" not in free[1]["content"] and "**No Deletion**" not in free[1]["content"]
        for phrase in ["Global Consistency","Auto-Numbering","No Filler"]:
            assert phrase in free[1]["content"] and phrase in base[1]["content"]
        assert "95%" in base[1]["content"]
        assert d in prompts.targeted_prompt(d,draft,language)[1]["content"]
        assert d in prompts.generic_prompt(d,draft,language)[1]["content"]
    assert legacy_skip(" NONE ") and not legacy_skip("No change. NONE")
    assert not legacy_skip("nonetheless") and not legacy_skip("None of these are captured")
    assert not legacy_skip("hydroquinone")
    assert not legacy_skip("Please add claim 2")
def safe_error(exc):
    return {"type":type(exc).__name__,"message":str(exc)[:180] if isinstance(exc,(ValueError,AssertionError,b.RunStopped)) else "Stage failed; inspect sanitized attempt records"}
class Client(b.Client):
    def __init__(self,config,stop):
        self.original_config=config
        api=dict(config,temperatures={"direct":config["temperatures"]["draft"],"feedback":config["temperatures"]["examiner"],"refine":config["temperatures"]["reviser"]})
        super().__init__(api,stop)
    def stage(self,dest,kind,messages,case):
        if (HERE/self.original_config["stop_file"]).exists():
            self.stop.set();raise b.RunStopped("STOP file present")
        name={"direct":"draft","feedback":"feedback","refine":"revision"}[kind]
        path=dest/(name+".json")
        if path.exists() and b.read(path)["status"]!="ok":
            raise ValueError("Persisted incomplete stage; no score-based retries")
        if not path.exists() and (dest/(name+".attempts.json")).exists():
            raise ValueError("Persisted failed or uncertain stage; manual accounting required")
        text=super().call(dest,name,kind,messages,case)
        return text,path
def rel(path):return str(path.relative_to(HERE))
def generate_case(client,config,case):
    lang,cid=case["language"],case["publication_number"]
    home=HERE/"cases"/lang/cid;errors=[]
    def fail(variant,exc):
        error={"language":lang,"publication_number":cid,"variant":variant,**safe_error(exc)}
        b.save(home/variant/"error.json",error);errors.append(error)
    try:
        raw,draft_path=client.stage(home/"_shared/draft","direct",prompts.draft_prompt(case["disclosure"],lang),case)
        draft=clean(raw)
        b.save(home/"draft_only/result.json",{"language":lang,"publication_number":cid,"variant":"draft_only","text":draft,"stage_paths":[rel(draft_path)],"completed_at":b.now()})
    except Exception as exc:
        for variant in VARIANTS:fail(variant,exc)
        return errors
    feedbacks={}
    rng=random.Random(int(b.sha(f"{config['seed']}:{lang}:{cid}:order".encode())[:16],16))
    kinds=["targeted","generic"];rng.shuffle(kinds)
    for kind in kinds:
        try:
            fn=prompts.targeted_prompt if kind=="targeted" else prompts.generic_prompt
            text,path=client.stage(home/"_shared"/kind,"feedback",fn(case["disclosure"],draft,lang),case)
            feedbacks[kind]=(text,path)
        except Exception as exc:feedbacks[kind]=exc
    variants=list(VARIANTS);rng.shuffle(variants)
    for variant in variants:
        try:
            item=feedbacks["generic" if variant=="generic_feedback" else "targeted"]
            if isinstance(item,Exception):raise item
            feedback,feedback_path=item
            skipped=legacy_skip(feedback);final=home/variant/"result.json"
            if final.exists():
                old=b.read(final)
                assert old["draft_sha256"]==b.sha(draft.encode()) and old["feedback_sha256"]==b.sha(feedback.encode())
                continue
            stage_paths=[rel(draft_path),rel(feedback_path)]
            if skipped:text=draft
            else:
                text,path=client.stage(home/variant,"refine",prompts.revision_prompt(variant,case["disclosure"],draft,feedback,lang),case)
                text=clean(text);stage_paths.append(rel(path))
            b.save(final,{"language":lang,"publication_number":cid,"variant":variant,"status":"complete",
                "text":text,"draft_sha256":b.sha(draft.encode()),"feedback_sha256":b.sha(feedback.encode()),
                "disclosure_sha256":b.sha(case["disclosure"].encode()),"revision_executed":not skipped,
                "legacy_none_skip":skipped,"exact_none_only":feedback.strip().upper()=="NONE",
                "none_contexts":[feedback[max(0,m.start()-35):m.end()+35] for m in re.finditer("NONE",feedback,re.I)],
                "stage_paths":stage_paths,"completed_at":b.now(),"numbered_claim_1":b.claim_format(text)})
        except Exception as exc:fail(variant,exc)
    return errors
def snapshot(config,phase,errors=None):
    counts={lang:{m:0 for m in ["draft_only"]+VARIANTS} for lang in ["en","zh"]}
    skips={lang:{m:0 for m in VARIANTS} for lang in ["en","zh"]}
    for p in (HERE/"cases").glob("*/*/*/result.json"):
        r=b.read(p);counts[r["language"]][r["variant"]]+=1
        if r.get("legacy_none_skip"):skips[r["language"]][r["variant"]]+=1
    tokens=Counter();attempts=0;uncertain=0
    for p in (HERE/"cases").rglob("*.attempts.json"):
        for a in b.read(p):
            attempts+=1;uncertain+=a.get("outcome")=="transport_uncertain"
            for k,v in a.get("usage",{}).items():
                if isinstance(v,(int,float)):tokens[k]+=v
    value={"phase":phase,"updated_at":b.now(),"counts":counts,"target_per_language":200,
           "skips":skips,"api_attempts":attempts,"transport_uncertain_attempts":uncertain,
           "reported_usage":dict(tokens),"errors":errors or [],"pid":os.getpid(),
           "cost_note":"Actual unique calls; incomplete/uncertain requests may have unreported usage. Standalone condition totals separately aggregate shared dependencies."}
    b.save(HERE/"status.json",value);return value
def export_results():
    for lang in ["en","zh"]:
        for variant in ["draft_only"]+VARIANTS:
            rows=[b.read(p) for p in (HERE/"cases"/lang).glob("*/"+variant+"/result.json")]
            b.save(HERE/"results"/(lang+"_"+variant+".json"),sorted(rows,key=lambda x:x["publication_number"]))
def validate_pilot(config,cases,selection):
    records=[];numbered=0;skips=0
    selected=[c for c in cases if c["publication_number"] in selection["pilot_ids"][c["language"]]]
    for case in selected:
        home=HERE/"cases"/case["language"]/case["publication_number"]
        draft=b.read(home/"draft_only/result.json")["text"]
        for variant in VARIANTS:
            r=b.read(home/variant/"result.json")
            assert r["draft_sha256"]==b.sha(draft.encode())
            assert r["disclosure_sha256"]==b.sha(case["disclosure"].encode())
            fb_path=home/"_shared"/("generic" if variant=="generic_feedback" else "targeted")/"feedback.json"
            fb=b.read(fb_path)["text"]
            assert r["feedback_sha256"]==b.sha(fb.encode()) and r["legacy_none_skip"]==legacy_skip(fb)
            if r["legacy_none_skip"]:assert r["text"]==draft
            expected=[prompts.draft_prompt(case["disclosure"],case["language"]),
                      (prompts.generic_prompt if variant=="generic_feedback" else prompts.targeted_prompt)(case["disclosure"],draft,case["language"])]
            if r["revision_executed"]:expected.append(prompts.revision_prompt(variant,case["disclosure"],draft,fb,case["language"]))
            for path,messages in zip(r["stage_paths"],expected):
                p=HERE/path;response=b.read(p)
                assert response["status"]=="ok" and response["finish_reason"]!="length"
                with gzip.open(p.with_suffix(".request.json.gz"),"rb") as f:wire=f.read()
                assert b.sha(wire)==response["request_sha256"] and json.loads(wire)["input"]["messages"]==messages
            assert len(r["stage_paths"])==len(expected)
            skips+=r["legacy_none_skip"];numbered+=r["numbered_claim_1"]
            s=structure_support.check(r["text"])
            records.append({"language":case["language"],"id":case["publication_number"],"variant":variant,"chars":len(r["text"]),"skipped":r["legacy_none_skip"],"parseable":s["parseable"],"claims":s["claims"],"first_text":r["text"][:120]})
    result={"passed":True,"paired_patents":len(selected),"variant_outputs":len(records),"numbered_claim1_outputs":numbered,"skips":skips,"checks":["frozen artifacts","exact shared drafts and feedback","intended prompt payloads","no reference field in generation","finished nonempty responses","resumable checkpoint provenance"],"scores_used_for_gate":False,"records":records}
    b.save(HERE/"pilot_validation.json",result);return result
def run(config,cases,selection,mode):
    lock=HERE/"run.lock"
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        stop=threading.Event();client=Client(config,stop)
        chosen=[c for c in cases if mode=="run" or c["publication_number"] in selection["pilot_ids"][c["language"]]]
        chosen.sort(key=lambda c:b.sha(f"{config['seed']}:{c['language']}:{c['publication_number']}".encode()))
        errors=[];finished=0;last=time.monotonic()
        b.emit(event="ablation_started",mode=mode,cases=len(chosen),variants=VARIANTS)
        snapshot(config,mode+"_running")
        with ThreadPoolExecutor(max_workers=config["workers"]) as pool:
            futures={pool.submit(generate_case,client,config,c):c for c in chosen}
            for f in as_completed(futures):
                errors.extend(f.result());finished+=1
                b.emit(event="case_finished",language=futures[f]["language"],id=futures[f]["publication_number"],done=finished,total=len(chosen),errors=len(errors))
                if time.monotonic()-last>30 or finished==len(chosen):
                    snapshot(config,mode+"_running",errors);last=time.monotonic()
                if stop.is_set():
                    for pending in futures:pending.cancel()
                    break
        export_results()
        value=snapshot(config,mode+("_complete" if not errors and finished==len(chosen) else "_incomplete"),errors)
        b.save(HERE/(mode+"_summary.json"),value)
        if mode=="pilot" and value["phase"]=="pilot_complete":validate_pilot(config,cases,selection)
        b.emit(event="ablation_finished",phase=value["phase"],counts=value["counts"],attempts=value["api_attempts"])
        return value["phase"]==mode+"_complete"
    finally:lock.unlink(missing_ok=True)
def main():
    p=argparse.ArgumentParser();p.add_argument("--mode",choices=["audit","pilot","run","status","validate-pilot"],required=True)
    args=p.parse_args();config=b.read(HERE/"config.json")
    if args.mode=="status":
        print(json.dumps(b.read(HERE/"status.json"),ensure_ascii=False,indent=2));return
    verify_frozen();prompt_audit();cases,selection=load_cases(config)
    if args.mode=="audit":
        result={"event":"audit_pass","generation_case_count":len(cases),"generation_fields":list(cases[0]),"pilot_ids":selection["pilot_ids"],"python":sys.version,"no_api_calls":True}
        b.save(HERE/"audit.json",result);print(json.dumps(result,ensure_ascii=False,indent=2));return
    if args.mode=="validate-pilot":
        print(json.dumps(validate_pilot(config,cases,selection),ensure_ascii=False,indent=2));return
    if args.mode=="run":assert b.read(HERE/"pilot_validation.json")["passed"],"Pilot validation required"
    sys.exit(0 if run(config,cases,selection,args.mode) else 2)
if __name__=="__main__":main()
