# Generated from sanitized original prompt assignments; no API calls here.

SOURCE_PROMPTS = {}

def draft_prompt(disclosure, language):
    TARGET_LANGUAGE = {'en': 'English', 'zh': 'Chinese'}[language]
    prompt = f'\n    You are a senior patent attorney proficient in patent law. \n    Please read the following [Technical Disclosure] and draft a complete set of patent claims that meet the standards for allowance. \n\n    ### ⚠️ CRITICAL LANGUAGE RULE ⚠️\n    You MUST output the final claims strictly in {TARGET_LANGUAGE}. \n    Ensure you use the standard, formal patent drafting terminology specific to {TARGET_LANGUAGE}.\n    \n    ### Requirements: \n    1. Independent claims must contain essential technical features to ensure novelty.\n    2. Dependent claims must provide progressive limitations. \n    3. The drafting must reflect rigorous logic and standardized patent terminology.\n    4. Output ONLY the claims, starting from "1. A..." without any conversational filler or explanations.\n\n    ### Input Data\n    [Technical Disclosure]:\n    {disclosure}\n    '
    messages = [{'role': 'system', 'content': 'You are a highly skilled Patent Attorney. You output strictly formatted patent claims based on technical disclosures.'}, {'role': 'user', 'content': prompt}]
    return messages

SOURCE_PROMPTS['draft_prompt'] = {'source': 'baseline1.py', 'original_function': 'call_qwen_draft_claims', 'extracted_sha256': '5d20346f61844f5be42e7f3bdae0cdd7dab3d1d48fbd093d2daeb276198cbeea'}

def targeted_prompt(disclosure, initial_draft, language):
    TARGET_LANGUAGE = {'en': 'English', 'zh': 'Chinese'}[language]
    prompt = f'\n    ### Task Objective\n    You are a Master Patent Strategist. Compare the [Initial Draft Claims] with the original [Technical Disclosure].\n    Your mission is to build a "Defensive Claim Tree" by extracting valuable technical details from the disclosure and adding them as fallback positions.\n\n    ### ⚠️ STRATEGIC RULES (MUST FOLLOW) ⚠️\n    1. **DO NOT TOUCH CLAIM 1**: The independent claim must remain broad. DO NOT add any new limitations to Claim 1.\n    2. **Hierarchical Expansion**: Dig deep into the [Technical Disclosure]. Find specific embodiments (e.g., specific temperatures, materials, exact mechanisms) that are missing from the current draft.\n    3. **Actionable Addition**: Instruct the attorney to add these missing specific features ONLY as NEW DEPENDENT CLAIMS at the end of the claim set. Do NOT output NONE unless the draft has exhausted every single detail from the disclosure.\n\n    ### Input Data\n    [Technical Disclosure]:\n    {disclosure}\n\n    [Initial Draft Claims]:\n    {initial_draft}\n\n    ### Output Requirements\n    **[Defect Analysis]**\n    (List the specific valuable features from the disclosure that are currently missing in the dependent claims.)\n\n    **[Revision Directives]**\n    (Provide exact commands to append new dependent claims. Write in {TARGET_LANGUAGE}.)\n    '
    messages = [{'role': 'system', 'content': 'You are a Master Patent Strategist focused on building robust defensive claim trees via dependent claims.'}, {'role': 'user', 'content': prompt}]
    return messages

SOURCE_PROMPTS['targeted_prompt'] = {'source': 'two-agents.py', 'original_function': 'call_qwen_examiner', 'extracted_sha256': '7b2793dd111f06d901939541b39fd96749f00745c8ad77a767bb5f91a79baf06'}

def anchored_prompt(initial_draft, critique, language):
    TARGET_LANGUAGE = {'en': 'English', 'zh': 'Chinese'}[language]
    prompt = f"""\n    You are a meticulous Senior Patent Attorney. \n    A Patent Examiner has reviewed your [Initial Draft Claims] and provided [Revision Directives].\n    Your task is to refine the claims by strictly incorporating the Examiner's feedback.\n\n    ### ⚠️ CRITICAL REWRITE RULES (CONSERVATIVE ANCHOR) ⚠️\n    1. **Conservative Refinement**: Your rewrite must be HIGHLY CONSERVATIVE. You MUST retain 95% of the original text structure. Simply weave the new requested features into the existing claims, or append new dependent claims.\n    2. **No Deletion**: DO NOT delete existing valid claims, steps, or features that were not explicitly criticized by the Examiner.\n    3. **Global Consistency**: Ensure the "antecedent basis" (e.g., 'a/an' vs 'the/said') is perfectly maintained after your edits.\n    4. **Auto-Numbering**: Ensure all claims are sequentially numbered.\n    5. **No Filler**: Output ONLY the full text of the revised claims, starting from "1. A...".\n\n    ### Input Data\n    [Initial Draft Claims]:\n    {initial_draft}\n\n    [Revision Directives]:\n    {critique}\n    """
    messages = [{'role': 'system', 'content': 'You are a meticulous Attorney. You weave changes into drafts while preserving original integrity.'}, {'role': 'user', 'content': prompt}]
    return messages

SOURCE_PROMPTS['anchored_prompt'] = {'source': 'two-agents.py', 'original_function': 'call_qwen_reviser', 'extracted_sha256': '5436bfc96960754e02ac723cb20ad0c7f2a4681443ca3f70202095d4bc8c5208'}
