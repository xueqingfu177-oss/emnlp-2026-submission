"""Offline execution tests for costly branching and shared artifacts."""
import json,tempfile,unittest
from pathlib import Path
import run_ablation as r
class Fake:
    def __init__(self,skip):self.skip=skip;self.calls=[]
    def stage(self,dest,kind,messages,case):
        self.calls.append((str(dest),kind,messages))
        if kind=="direct":text="1. A sensor.\n2. The sensor of claim 1."
        elif kind=="feedback":text="NONE" if self.skip and dest.name=="targeted" else "Add a supported dependent claim."
        else:text="1. A sensor.\n2. The sensor of claim 1.\n3. The sensor of claim 1, with a housing."
        return text,dest/({"direct":"draft","feedback":"feedback","refine":"revision"}[kind]+".json")
class Protocol(unittest.TestCase):
    def test_prompts(self):r.prompt_audit()
    def test_shared_and_skip(self):
        for skip in [False,True]:
            with tempfile.TemporaryDirectory() as td:
                old=r.HERE;r.HERE=Path(td)
                try:
                    client=Fake(skip)
                    self.assertEqual(r.generate_case(client,{"seed":20261002},{"language":"en","publication_number":"SYNTHETIC","disclosure":"A sensor with a housing."}),[])
                    self.assertEqual(len(client.calls),4 if skip else 7)
                    rows=[r.b.read(r.HERE/"cases/en/SYNTHETIC"/v/"result.json") for v in r.VARIANTS]
                    self.assertEqual(len({x["draft_sha256"] for x in rows}),1)
                    self.assertEqual(len({x["feedback_sha256"] for x in rows if x["variant"]!="generic_feedback"}),1)
                    self.assertEqual(sum(x["legacy_none_skip"] for x in rows),3 if skip else 0)
                    self.assertEqual(sum(x["revision_executed"] for x in rows),1 if skip else 4)
                finally:r.HERE=old
if __name__=="__main__":unittest.main()
