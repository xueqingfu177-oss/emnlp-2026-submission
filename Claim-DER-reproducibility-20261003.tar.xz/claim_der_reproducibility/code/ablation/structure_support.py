"""Conservative bilingual checks of explicit claim numbering and references.

This is a syntactic diagnostic, not patent-law validity or semantic dependency.
Unparseable sets are never counted as passing. Multiple independent claims and
multiple parents are allowed. Numberless claim sets are not silently renumbered.
"""
import argparse, csv, hashlib, json, random, re, statistics
from collections import Counter
from pathlib import Path

METHODS=['ft_llama3','qwen_turbo','qwen_max','self_refine','implicit_cot','plangen_bon5','claim_der']
LABELS=['FT-Llama3','Qwen-Turbo','Qwen-Max','Self-Refine','Implicit CoT','PlanGEN-BoN5','Claim-DER']
HEADER=re.compile(r'(?m)^[ \t]*(?:#{1,4}[ \t]+)?(?:\*\*)?(?:Claim[ \t]+|权利要求[ \t]*)?(\d{1,3})[.．、:：)](?!\d)[ \t]*(?:\*\*)?[ \t]*',re.I)
START=re.compile(r'^(?:\*\*)?(?:A\b|An\b|The\b|Uses?\b|Method\b|Process\b|Apparatus\b|Device\b|Composition\b|According\b|Insulin-producing\b|Free\b|Host cells\b|Egg cells\b|Fertilized eggs\b|Aromatic polyether\b|Plant matter\b|Allulose\b|一种|一项|一个|根据|如权利要求|如第|权利要求|按照|依照|所述)',re.I)
REF=re.compile(r'\bclaims?\b|权利要求',re.I)
NUMSEQ=re.compile(r'\s*(\d{1,3}(?:(?:\s*(?:[-‐‑‒–—~～至到]|\bto\b|\bthrough\b)\s*|\s*[,，、]\s*(?:(?:and|or)\s+)?|\s+(?:and|or)\s+|\s*[或和及]\s*)\d{1,3})*)',re.I)
REL_EN=re.compile(r'(?:(?:any(?:\s+one)?\s+of\s+)?(?:the\s+)?(?:preceding|previous|foregoing|above)\s+claims?)',re.I)
REL_ZH=re.compile(r'(?:前述|上述|前面)(?:(?:任意|任一|任何)(?:一)?项?)?权利要求')

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csvwrite(p,rows):
    if not rows:return
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def parse_claims(text):
    text=text.replace('\r\n','\n').replace('\r','\n')
    matches=list(HEADER.finditer(text))
    flags=[]
    if not matches:return [],['no_explicit_numbered_claims']
    prefix=text[:matches[0].start()].strip(' \n`*#:')
    if prefix and not re.fullmatch(r'(?:claims?|权利要求书|权利要求)(?:\s*[:：])?',prefix,re.I):
        flags.append('unparsed_prefix')
    claims=[]
    for i,m in enumerate(matches):
        body=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)].strip().strip('`').strip()
        if not body:flags.append('empty_claim')
        elif not START.match(body):flags.append('ambiguous_numbered_block')
        # A claim-looking line without a number may be an omitted header.
        if re.search(r'(?m)^\s*(?:The .{0,60}(?:of|according to) claim\s+\d|根据权利要求\d)',body):
            # The first line is already part of the current header.
            for line in body.splitlines()[1:]:
                if re.match(r'\s*(?:The .{0,60}(?:of|according to) claim\s+\d|根据权利要求\d)',line):
                    flags.append('possible_unnumbered_claim')
        claims.append({'id':int(m.group(1)),'text':body})
    return claims,sorted(set(flags))

def references(body,cid):
    refs=set();unparsed=[];covered=[]
    for pat in [REL_EN,REL_ZH]:
        for m in pat.finditer(body):
            phrase=m.group(0).lower()
            plural=phrase.endswith('claims') or any(x in phrase for x in ['any','任','任何'])
            refs.update(range(1,cid) if plural else [cid-1])
            covered.append(m.span())
    for m in REF.finditer(body):
        if any(a<=m.start()<b for a,b in covered):continue
        x=NUMSEQ.match(body,m.end())
        if not x:
            unparsed.append(body[max(0,m.start()-15):m.end()+40]);continue
        sequence=x.group(1)
        suffix=re.match(r'(?:中|的)?(?:任一|任意一|任意|任何一)项?权利要求',body[x.end():])
        if suffix:covered.append((x.end(),x.end()+suffix.end()))
        invalid=False
        for r in re.finditer(r'(\d{1,3})\s*(?:[-‐‑‒–—~～至到]|\bto\b|\bthrough\b)\s*(\d{1,3})',sequence,re.I):
            lo,hi=map(int,r.groups())
            if lo>hi:invalid=True
            else:refs.update(range(lo,hi+1))
        refs.update(map(int,re.findall(r'\d+',sequence)))
        if invalid:unparsed.append('descending_range:'+sequence)
    return sorted(refs),unparsed

def check(text):
    claims,flags=parse_claims(text)
    ids=[c['id'] for c in claims];idset=set(ids)
    duplicate=len(ids)-len(idset)
    numbering_bad=bool(claims) and ids!=list(range(1,len(ids)+1))
    edges=[];unknown=[]
    for c in claims:
        parents,u=references(c['text'],c['id']);unknown.extend(u)
        edges.extend((c['id'],p) for p in parents)
        c['parents']=parents
    if unknown:flags.append('unparsed_reference')
    missing=[(c,p) for c,p in edges if p not in idset]
    selfrefs=[(c,p) for c,p in edges if c==p]
    forward=[(c,p) for c,p in edges if p>c]
    invalid=[(c,p) for c,p in edges if p not in idset or p>=c]
    adjacency={i:[] for i in ids}
    for c,p in edges:
        if p in idset:adjacency[c].append(p)
    done=set();visiting=set()
    def dfs(n):
        if n in visiting:return True
        if n in done:return False
        visiting.add(n)
        cyclic=any(dfs(p) for p in adjacency[n])
        visiting.remove(n);done.add(n)
        return cyclic
    cycle=any(dfs(n) for n in ids)
    roots=sum(not c['parents'] for c in claims)
    parsed=bool(claims) and not flags
    passed=parsed and not (numbering_bad or invalid or cycle) and roots>0
    return {'parseable':parsed,'claims':len(claims),'edges':len(edges),
            'duplicate_ids':duplicate,'numbering_error':bool(numbering_bad),
            'missing_parent_edges':len(missing),'self_edges':len(selfrefs),
            'forward_edges':len(forward),'invalid_edges':len(invalid),'cycle':cycle,
            'root_claims':roots,'pass':bool(passed),'flags':sorted(set(flags)),
            'claim_records':claims,'unparsed_references':unknown,
            'invalid_edge_details':invalid}

def tests():
    cases=[
      ('1. A device.\n2. The device of claim 1.',True,0,False),
      ('1. A device.\n2. A method.',True,0,False),
      ('1. A device.\n2. The device of claim 2.',False,1,True),
      ('1. The device of claim 2.\n2. The device of claim 1.',False,1,True),
      ('1. A device.\n2. The device of claim 8.',False,1,False),
      ('1. A device.\n2. A method.\n3. The device of claims 1 and 2.',True,0,False),
      ('1. A device.\n2. A method.\n3. The device of claims 1–2.',True,0,False),
      ('1.一种装置。\n2.一种方法。\n3.根据权利要求1至2所述的装置。',True,0,False),
      ('1. A device.\n2. The device of any preceding claim.',True,0,False),
      ('1.一种装置。\n2.根据前述任一项权利要求所述的装置。',True,0,False),
      ('A device.\nThe device of claim 1.',False,0,False),
      ('1. A device.\n1. A method.',False,0,False),
      ('1. A device.\n3. The device of claim 1.',False,0,False),
      ('1. A device.\n2. The device of claim X.',False,0,False),
      ('1. A device with dimensions 1.5 mm.\n2. The device of claim 1.',True,0,False),
      ('1. A device, comprising:\n(a) a lamp;\n(b) a cell.\n2. The device of claim 1.',True,0,False),
      ('1. A device.\n2. The device of claims 3 to 1.',False,1,False),
    ]
    for txt,p,e,c in cases:
        r=check(txt)
        assert (r['pass'],r['invalid_edges'],r['cycle'])==(p,e,c),(txt,r)
    assert references('The device of claims 1, 2, or 3.',4)[0]==[1,2,3]
    assert references('根据权利要求1、2或3所述的装置。',4)[0]==[1,2,3]
    assert references('如权利要求1‑3中任一项权利要求所述的方法。',4)==([1,2,3],[])
    print('STRUCTURE_TESTS_PASS',len(cases)+3)

