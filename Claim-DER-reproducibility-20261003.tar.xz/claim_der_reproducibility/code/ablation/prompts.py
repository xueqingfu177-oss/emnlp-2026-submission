"""Three targeted design interventions on extracted original prompt templates."""
from original_prompts import draft_prompt,targeted_prompt,anchored_prompt

def generic_prompt(disclosure,initial_draft,language):
    target={"en":"English","zh":"Chinese"}[language]
    user=f"""### Task Objective
You are a Master Patent Strategist. Compare the [Initial Draft Claims] with the original [Technical Disclosure].
Review the overall drafting quality of the initial claims, including completeness, factual support, clarity, terminology consistency, and dependency relationships.

### Review Instructions
Identify specific drafting problems and provide actionable edits to address them. Explain which parts are already adequate.
Use the disclosure as the factual authority. Do not invent technical details.
Output NONE only if no revisions are needed.

### Input Data
[Technical Disclosure]:
{disclosure}

[Initial Draft Claims]:
{initial_draft}

### Output Requirements
**[Defect Analysis]**
(List the specific drafting problems you identified.)

**[Revision Directives]**
(Provide concrete revision instructions. Write in {target}.)"""
    return [{"role":"system","content":"You are a Master Patent Strategist who reviews patent drafting quality and provides actionable revision feedback."},{"role":"user","content":user}]

REMOVE_RULES=[
    '    1. **Conservative Refinement**: Your rewrite must be HIGHLY CONSERVATIVE. You MUST retain 95% of the original text structure. Simply weave the new requested features into the existing claims, or append new dependent claims.\n',
    '    2. **No Deletion**: DO NOT delete existing valid claims, steps, or features that were not explicitly criticized by the Examiner.\n'
]

def revision_prompt(variant,disclosure,draft,feedback,language):
    messages=anchored_prompt(draft,feedback,language)
    if variant=="full_disclosure":
        messages[1]["content"] += "\n[Technical Disclosure]:\n"+disclosure
    elif variant=="free_reviser":
        text=messages[1]["content"]
        for rule in REMOVE_RULES:
            assert text.count(rule)==1
            text=text.replace(rule,"",1)
        text=text.replace("CRITICAL REWRITE RULES (CONSERVATIVE ANCHOR)","REWRITE RULES",1)
        messages[1]["content"]=text
        messages[0]["content"]="You are a meticulous Attorney. You revise patent claims according to the supplied feedback."
    else:
        assert variant in ["full_der","generic_feedback"]
    return messages
